"""
Database helper for Career Compass.

The app prefers MySQL when MYSQL_HOST is configured and reachable.
If MySQL is not available it uses a local SQLite file so the project
still runs for a classroom demo.

Every query uses placeholders (?, converted to %s for MySQL) so user
input is never concatenated into SQL.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager

from config import Config

_backend = None  # "mysql" or "sqlite"


def detect_backend():
    """Return 'mysql' if a MySQL server is configured and reachable, else 'sqlite'."""
    global _backend
    if _backend:
        return _backend
    if Config.MYSQL_HOST:
        try:
            import mysql.connector

            conn = mysql.connector.connect(
                host=Config.MYSQL_HOST,
                port=Config.MYSQL_PORT,
                user=Config.MYSQL_USER,
                password=Config.MYSQL_PASSWORD,
                database=Config.MYSQL_DATABASE,
                connection_timeout=3,
            )
            conn.close()
            _backend = "mysql"
            return _backend
        except Exception:
            _backend = "sqlite"
            return _backend
    _backend = "sqlite"
    return _backend


def _adapt_sql(sql):
    if detect_backend() == "mysql":
        return sql.replace("?", "%s")
    return sql


def connect():
    """Open a new database connection."""
    if detect_backend() == "mysql":
        import mysql.connector

        conn = mysql.connector.connect(
            host=Config.MYSQL_HOST,
            port=Config.MYSQL_PORT,
            user=Config.MYSQL_USER,
            password=Config.MYSQL_PASSWORD,
            database=Config.MYSQL_DATABASE,
            autocommit=False,
        )
        return conn

    conn = sqlite3.connect(Config.SQLITE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _cursor(conn):
    if detect_backend() == "mysql":
        return conn.cursor(dictionary=True)
    return conn.cursor()


def _as_dict(cursor, row):
    if row is None:
        return None
    if isinstance(row, dict):
        return row
    columns = [col[0] for col in cursor.description]
    return dict(zip(columns, row))


def fetch_all(sql, params=()):
    conn = connect()
    try:
        cur = _cursor(conn)
        cur.execute(_adapt_sql(sql), tuple(params))
        rows = cur.fetchall()
        if detect_backend() == "mysql":
            return list(rows)
        return [dict(r) for r in rows]
    finally:
        conn.close()


def fetch_one(sql, params=()):
    conn = connect()
    try:
        cur = _cursor(conn)
        cur.execute(_adapt_sql(sql), tuple(params))
        row = cur.fetchone()
        return _as_dict(cur, row)
    finally:
        conn.close()


def execute(sql, params=(), many=False):
    """Run INSERT/UPDATE/DELETE. Returns lastrowid for single inserts."""
    conn = connect()
    try:
        cur = _cursor(conn)
        adapted = _adapt_sql(sql)
        if many:
            cur.executemany(adapted, params)
            conn.commit()
            return cur.rowcount
        cur.execute(adapted, tuple(params))
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def execute_script(statements):
    conn = connect()
    try:
        cur = _cursor(conn)
        for sql in statements:
            cur.execute(sql)
        conn.commit()
    finally:
        conn.close()


@contextmanager
def transaction():
    conn = connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


SQLITE_SCHEMA = [
    """
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        city TEXT NOT NULL DEFAULT 'Bengaluru',
        career_hunch TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS quiz_categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        slug TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        accent TEXT NOT NULL DEFAULT 'teal'
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS quiz_questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER NOT NULL,
        question_text TEXT NOT NULL,
        question_type TEXT NOT NULL DEFAULT 'likert',
        dimension TEXT NOT NULL,
        image_icon TEXT DEFAULT '',
        is_active INTEGER NOT NULL DEFAULT 1,
        display_order INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES quiz_categories(id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS question_options (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question_id INTEGER NOT NULL,
        option_text TEXT NOT NULL,
        option_emoji TEXT DEFAULT '',
        score_value INTEGER NOT NULL DEFAULT 1,
        dimension TEXT DEFAULT '',
        display_order INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (question_id) REFERENCES quiz_questions(id) ON DELETE CASCADE
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS quiz_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        category_id INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'in_progress',
        current_index INTEGER NOT NULL DEFAULT 0,
        started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        paused_at TEXT,
        completed_at TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (category_id) REFERENCES quiz_categories(id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS user_answers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        attempt_id INTEGER NOT NULL,
        question_id INTEGER NOT NULL,
        option_id INTEGER NOT NULL,
        score_value INTEGER NOT NULL,
        answered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE (attempt_id, question_id),
        FOREIGN KEY (attempt_id) REFERENCES quiz_attempts(id) ON DELETE CASCADE,
        FOREIGN KEY (question_id) REFERENCES quiz_questions(id),
        FOREIGN KEY (option_id) REFERENCES question_options(id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS quiz_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        attempt_id INTEGER NOT NULL,
        category_id INTEGER NOT NULL,
        scores_json TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (attempt_id) REFERENCES quiz_attempts(id),
        FOREIGN KEY (category_id) REFERENCES quiz_categories(id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS career_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        summary TEXT NOT NULL,
        strengths_text TEXT NOT NULL,
        growth_text TEXT NOT NULL,
        subjects_text TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS career_profile_weights (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        career_id INTEGER NOT NULL,
        trait_key TEXT NOT NULL,
        weight REAL NOT NULL,
        FOREIGN KEY (career_id) REFERENCES career_profiles(id) ON DELETE CASCADE
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS job_opportunities (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        organization TEXT NOT NULL,
        city TEXT NOT NULL,
        career_field TEXT NOT NULL,
        required_skills TEXT NOT NULL,
        experience_level TEXT NOT NULL,
        apply_url TEXT NOT NULL DEFAULT '#',
        is_sample INTEGER NOT NULL DEFAULT 1
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS combined_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        hunch TEXT,
        scores_json TEXT NOT NULL,
        matches_json TEXT NOT NULL,
        strengths_json TEXT NOT NULL,
        growth_json TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS user_reflections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        result_id INTEGER,
        note TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS admin_audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admin_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        details TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (admin_id) REFERENCES admins(id)
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)",
    "CREATE INDEX IF NOT EXISTS idx_questions_category ON quiz_questions(category_id, is_active, display_order)",
    "CREATE INDEX IF NOT EXISTS idx_attempts_user ON quiz_attempts(user_id, category_id, status)",
    "CREATE INDEX IF NOT EXISTS idx_answers_attempt ON user_answers(attempt_id)",
    "CREATE INDEX IF NOT EXISTS idx_jobs_city ON job_opportunities(city, career_field)",
]


def init_db():
    """Create tables (SQLite) and seed required rows if the database is empty."""
    from seed_data import ADMIN_PASSWORD_HASH, seed_all

    if detect_backend() == "sqlite":
        execute_script(SQLITE_SCHEMA)

    admin = fetch_one("SELECT id FROM admins LIMIT 1")
    if not admin:
        execute(
            "INSERT INTO admins (username, password_hash) VALUES (?, ?)",
            (Config.ADMIN_USERNAME, ADMIN_PASSWORD_HASH),
        )

    questions = fetch_one("SELECT id FROM quiz_questions LIMIT 1")
    if not questions:
        seed_all()
