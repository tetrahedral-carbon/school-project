"""
PDF report builder using ReportLab.

The file is generated in memory and sent as a download. No paid
WeasyPrint system libraries are required, which keeps the project
easy to run on a school computer.
"""

from io import BytesIO
from datetime import datetime

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    ListFlowable,
    ListItem,
    HRFlowable,
    KeepTogether,
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

NAVY = colors.HexColor("#0B1B4A")
TEAL = colors.HexColor("#1AA7A1")
CORAL = colors.HexColor("#E85D4C")
CREAM = colors.HexColor("#F4F0E6")
INK = colors.HexColor("#1A1F36")
MUTED = colors.HexColor("#5C6378")


def build_report_pdf(user, report):
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=18 * mm,
        rightMargin=18 * mm,
        topMargin=16 * mm,
        bottomMargin=16 * mm,
        title="Career Compass Report",
        author="Career Compass",
    )
    styles = getSampleStyleSheet()
    title = ParagraphStyle(
        "CCTitle",
        parent=styles["Title"],
        fontName="Times-Bold",
        fontSize=22,
        textColor=NAVY,
        spaceAfter=4,
        alignment=0,
    )
    subtitle = ParagraphStyle(
        "CCSub",
        parent=styles["Normal"],
        fontSize=11,
        textColor=TEAL,
        spaceAfter=12,
    )
    heading = ParagraphStyle(
        "CCHead",
        parent=styles["Heading2"],
        fontName="Times-Bold",
        fontSize=13,
        textColor=NAVY,
        spaceBefore=10,
        spaceAfter=6,
    )
    body = ParagraphStyle(
        "CCBody",
        parent=styles["Normal"],
        fontSize=10,
        leading=14,
        textColor=INK,
        spaceAfter=6,
    )
    small = ParagraphStyle(
        "CCSmall",
        parent=styles["Normal"],
        fontSize=8.5,
        leading=12,
        textColor=MUTED,
    )
    label = ParagraphStyle(
        "CCLabel",
        parent=styles["Normal"],
        fontSize=9,
        textColor=CORAL,
        spaceBefore=4,
    )

    story = []
    name = user.get("full_name") or user.get("username")
    today = datetime.now().strftime("%d %B %Y")

    story.append(Paragraph("CAREER COMPASS", title))
    story.append(Paragraph("Discover your direction. Design your future.", subtitle))
    story.append(
        Paragraph(
            f"<b>Student:</b> {name} &nbsp;&nbsp; <b>Username:</b> {user['username']}<br/>"
            f"<b>City:</b> {user.get('city') or '—'} &nbsp;&nbsp; <b>Report date:</b> {today}",
            body,
        )
    )
    story.append(HRFlowable(width="100%", thickness=1, color=TEAL, spaceAfter=10))

    story.append(Paragraph("Career hunch", heading))
    hunch = user.get("career_hunch") or "No hunch was saved."
    story.append(Paragraph(hunch, body))
    story.append(Paragraph(report.get("hunch_note") or "", body))

    story.append(Paragraph("Quiz scores (0–100)", heading))
    score_rows = [["Trait", "Score"]]
    for key, value in sorted(report.get("scores", {}).items(), key=lambda item: -item[1]):
        from scoring import TRAIT_LABELS

        score_rows.append([TRAIT_LABELS.get(key, key), f"{value:.1f}"])
    if len(score_rows) == 1:
        score_rows.append(["No scores yet", "—"])
    table = Table(score_rows, colWidths=[120 * mm, 40 * mm])
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), NAVY),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("BACKGROUND", (0, 1), (-1, -1), CREAM),
                ("TEXTCOLOR", (0, 1), (-1, -1), INK),
                ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#D9D3C4")),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    story.append(table)
    story.append(Spacer(1, 8))

    story.append(Paragraph("Strengths", heading))
    for item in report.get("strengths") or []:
        story.append(Paragraph(f"• {item['label']} — {item['score']}", body))

    story.append(Paragraph("Growth areas", heading))
    for item in report.get("growth") or []:
        story.append(Paragraph(f"• {item['label']} — {item['score']}", body))

    story.append(Paragraph("Top career matches", heading))
    for item in report.get("matches") or []:
        block = [
            Paragraph(f"{item['title']}  —  match {item['match_score']}", heading),
            Paragraph(item["summary"], body),
            Paragraph(f"<b>Why it may fit:</b> {item['strengths']}", body),
            Paragraph(f"<b>Grow next:</b> {item['growth']}", body),
            Paragraph(f"<b>Subjects:</b> {item['subjects']}", body),
        ]
        road = item.get("roadmap") or {}
        if road:
            block.append(Paragraph("<b>Roadmap</b>", label))
            block.append(Paragraph(f"Next 1–3 months: {road.get('now', '')}", body))
            block.append(Paragraph(f"3–12 months: {road.get('short', '')}", body))
            block.append(Paragraph(f"1–3 years: {road.get('long', '')}", body))
        story.append(KeepTogether(block))

    story.append(Paragraph("Nearby sample opportunities", heading))
    story.append(
        Paragraph(
            "These listings come from the local Career Compass database. "
            "They are labelled sample opportunities, not live vacancies.",
            small,
        )
    )
    jobs = report.get("jobs") or []
    if not jobs:
        story.append(Paragraph("No sample roles matched this city yet.", body))
    for job in jobs:
        story.append(
            Paragraph(
                f"<b>{job['title']}</b> — {job['organization']} ({job['city']}) · "
                f"{job['career_field']} · {job['experience_level']} · {job['required_skills']}",
                body,
            )
        )

    story.append(Paragraph("Chart scores (text version)", heading))
    radar = report.get("radar") or {}
    for label, value in zip(radar.get("labels") or [], radar.get("values") or []):
        story.append(Paragraph(f"• {label}: {value}", body))

    story.append(Spacer(1, 12))
    story.append(HRFlowable(width="100%", thickness=0.6, color=NAVY, spaceAfter=8))
    story.append(
        Paragraph(
            "This quiz is for educational career exploration only. "
            "It is not a professional psychological assessment or a guarantee of career outcomes.",
            small,
        )
    )
    story.append(
        Paragraph(
            "Generated by Career Compass · Class project software · Scores are transparent weighted averages.",
            small,
        )
    )

    def _header_footer(canvas, doc_):
        canvas.saveState()
        canvas.setFillColor(NAVY)
        canvas.rect(0, A4[1] - 8 * mm, A4[0], 8 * mm, fill=1, stroke=0)
        canvas.setFillColor(TEAL)
        canvas.rect(0, 0, A4[0], 8 * mm, fill=1, stroke=0)
        canvas.setFillColor(colors.white)
        canvas.setFont("Helvetica", 8)
        canvas.drawString(18 * mm, 3 * mm, "Career Compass  ·  educational exploration only")
        canvas.drawRightString(A4[0] - 18 * mm, 3 * mm, f"Page {doc_.page}")
        canvas.restoreState()

    doc.build(story, onFirstPage=_header_footer, onLaterPages=_header_footer)
    buffer.seek(0)
    return buffer
