-- Career Compass MySQL 8 schema
-- Creates the database and every table used by the Flask app.
-- Import with: mysql -u root -p < database/schema.sql

CREATE DATABASE IF NOT EXISTS career_compass_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE career_compass_db;

-- Student accounts. Passwords are stored only as Werkzeug hashes.
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(20) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(80) NOT NULL,
  city VARCHAR(80) NOT NULL DEFAULT 'Bengaluru',
  career_hunch VARCHAR(200) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) COMMENT='Registered students';

-- Separate admin table so student accounts cannot reach the console.
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(40) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) COMMENT='Staff accounts for the question workshop';

-- The three assessment chapters.
CREATE TABLE IF NOT EXISTS quiz_categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(40) NOT NULL UNIQUE,
  name VARCHAR(80) NOT NULL,
  description VARCHAR(255) NOT NULL,
  accent VARCHAR(20) NOT NULL DEFAULT 'teal'
) COMMENT='Personality, skills, interests';

-- Individual quiz items. Admin edits write here and appear live.
CREATE TABLE IF NOT EXISTS quiz_questions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_id INT NOT NULL,
  question_text TEXT NOT NULL,
  question_type ENUM('scenario','likert') NOT NULL DEFAULT 'likert',
  dimension VARCHAR(40) NOT NULL,
  image_icon VARCHAR(40) DEFAULT '',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  display_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_questions_category FOREIGN KEY (category_id) REFERENCES quiz_categories(id)
) COMMENT='Question bank';

-- Answer choices, including 1-5 scale labels.
CREATE TABLE IF NOT EXISTS question_options (
  id INT AUTO_INCREMENT PRIMARY KEY,
  question_id INT NOT NULL,
  option_text VARCHAR(400) NOT NULL,
  option_emoji VARCHAR(16) DEFAULT '',
  score_value TINYINT NOT NULL DEFAULT 1,
  dimension VARCHAR(40) DEFAULT '',
  display_order INT NOT NULL DEFAULT 0,
  CONSTRAINT fk_options_question FOREIGN KEY (question_id) REFERENCES quiz_questions(id) ON DELETE CASCADE
) COMMENT='Options and option scores';

-- One row per try. New attempts never overwrite older ones.
CREATE TABLE IF NOT EXISTS quiz_attempts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  category_id INT NOT NULL,
  status ENUM('in_progress','paused','completed') NOT NULL DEFAULT 'in_progress',
  current_index INT NOT NULL DEFAULT 0,
  started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  paused_at TIMESTAMP NULL,
  completed_at TIMESTAMP NULL,
  CONSTRAINT fk_attempts_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_attempts_category FOREIGN KEY (category_id) REFERENCES quiz_categories(id)
) COMMENT='Paused and completed quiz tries';

-- Auto-saved answers. Unique per attempt + question.
CREATE TABLE IF NOT EXISTS user_answers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  attempt_id INT NOT NULL,
  question_id INT NOT NULL,
  option_id INT NOT NULL,
  score_value TINYINT NOT NULL,
  answered_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_attempt_question (attempt_id, question_id),
  CONSTRAINT fk_answers_attempt FOREIGN KEY (attempt_id) REFERENCES quiz_attempts(id) ON DELETE CASCADE,
  CONSTRAINT fk_answers_question FOREIGN KEY (question_id) REFERENCES quiz_questions(id),
  CONSTRAINT fk_answers_option FOREIGN KEY (option_id) REFERENCES question_options(id)
) COMMENT='Student answers';

-- Snapshot of scores when a chapter is submitted.
CREATE TABLE IF NOT EXISTS quiz_results (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  attempt_id INT NOT NULL,
  category_id INT NOT NULL,
  scores_json JSON NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_qresults_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_qresults_attempt FOREIGN KEY (attempt_id) REFERENCES quiz_attempts(id),
  CONSTRAINT fk_qresults_category FOREIGN KEY (category_id) REFERENCES quiz_categories(id)
) COMMENT='Per-chapter score snapshots';

CREATE TABLE IF NOT EXISTS career_profiles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  summary TEXT NOT NULL,
  strengths_text TEXT NOT NULL,
  growth_text TEXT NOT NULL,
  subjects_text TEXT NOT NULL
) COMMENT='Careers the engine can recommend';

CREATE TABLE IF NOT EXISTS career_profile_weights (
  id INT AUTO_INCREMENT PRIMARY KEY,
  career_id INT NOT NULL,
  trait_key VARCHAR(40) NOT NULL,
  weight DECIMAL(4,2) NOT NULL,
  CONSTRAINT fk_weights_career FOREIGN KEY (career_id) REFERENCES career_profiles(id) ON DELETE CASCADE
) COMMENT='How strongly each trait supports a career';

-- Clearly labelled sample opportunities, not live vacancies.
CREATE TABLE IF NOT EXISTS job_opportunities (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(160) NOT NULL,
  organization VARCHAR(160) NOT NULL,
  city VARCHAR(80) NOT NULL,
  career_field VARCHAR(120) NOT NULL,
  required_skills VARCHAR(255) NOT NULL,
  experience_level VARCHAR(40) NOT NULL,
  apply_url VARCHAR(255) NOT NULL DEFAULT '#',
  is_sample TINYINT(1) NOT NULL DEFAULT 1
) COMMENT='Local sample jobs / internships / events';

CREATE TABLE IF NOT EXISTS combined_results (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  hunch VARCHAR(200) NULL,
  scores_json JSON NOT NULL,
  matches_json JSON NOT NULL,
  strengths_json JSON NOT NULL,
  growth_json JSON NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_combined_user FOREIGN KEY (user_id) REFERENCES users(id)
) COMMENT='Full report snapshots';

CREATE TABLE IF NOT EXISTS user_reflections (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  result_id INT NULL,
  note TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_reflect_user FOREIGN KEY (user_id) REFERENCES users(id)
) COMMENT='Student notes on the results page';

CREATE TABLE IF NOT EXISTS admin_audit_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  admin_id INT NOT NULL,
  action VARCHAR(80) NOT NULL,
  details VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_audit_admin FOREIGN KEY (admin_id) REFERENCES admins(id)
) COMMENT='Admin add/edit/delete history';

CREATE INDEX idx_users_username ON users (username);
CREATE INDEX idx_questions_category ON quiz_questions (category_id, is_active, display_order);
CREATE INDEX idx_attempts_user ON quiz_attempts (user_id, category_id, status);
CREATE INDEX idx_answers_attempt ON user_answers (attempt_id);
CREATE INDEX idx_jobs_city ON job_opportunities (city, career_field);
