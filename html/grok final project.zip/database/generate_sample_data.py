"""One-off helper to print MySQL inserts from seed_data.py."""
from seed_data import (
    ADMIN_PASSWORD_HASH,
    CATEGORIES,
    CAREERS,
    JOBS,
    LIKERT_LABELS,
    PERSONALITY_QUESTIONS,
    SKILLS_QUESTIONS,
    INTERESTS_QUESTIONS,
)


def esc(value):
    return str(value).replace("\\", "\\\\").replace("'", "\\'")


lines = [
    "-- Career Compass sample / seed data for MySQL",
    "-- Demo admin password is Admin123 (hashed). Change it before real use.",
    "USE career_compass_db;",
    "",
    f"INSERT INTO admins (username, password_hash) VALUES ('Admin', '{ADMIN_PASSWORD_HASH}');",
    "",
]
for cat in CATEGORIES:
    lines.append(
        "INSERT INTO quiz_categories (slug, name, description, accent) VALUES "
        f"('{esc(cat['slug'])}', '{esc(cat['name'])}', '{esc(cat['description'])}', '{esc(cat['accent'])}');"
    )

lines += ["", "-- Personality questions"]
for index, item in enumerate(PERSONALITY_QUESTIONS, start=1):
    lines.append(
        "INSERT INTO quiz_questions (category_id, question_text, question_type, dimension, image_icon, is_active, display_order) "
        f"SELECT id, '{esc(item['text'])}', 'scenario', '{esc(item['dimension'])}', '{esc(item['icon'])}', 1, {index} "
        "FROM quiz_categories WHERE slug = 'personality';"
    )
    for opt_i, opt in enumerate(item["options"], start=1):
        text, emoji, score, dim = opt
        lines.append(
            "INSERT INTO question_options (question_id, option_text, option_emoji, score_value, dimension, display_order) "
            f"SELECT MAX(id), '{esc(text)}', '{esc(emoji)}', {score}, '{esc(dim)}', {opt_i} FROM quiz_questions;"
        )

lines += ["", "-- Skills questions"]
for index, item in enumerate(SKILLS_QUESTIONS, start=1):
    text, dimension, icon = item
    lines.append(
        "INSERT INTO quiz_questions (category_id, question_text, question_type, dimension, image_icon, is_active, display_order) "
        f"SELECT id, '{esc(text)}', 'likert', '{esc(dimension)}', '{esc(icon)}', 1, {index} "
        "FROM quiz_categories WHERE slug = 'skills';"
    )
    for opt_i, (score, label, mark) in enumerate(LIKERT_LABELS, start=1):
        lines.append(
            "INSERT INTO question_options (question_id, option_text, option_emoji, score_value, dimension, display_order) "
            f"SELECT MAX(id), '{esc(label)}', '{esc(mark)}', {score}, '{esc(dimension)}', {opt_i} FROM quiz_questions;"
        )

lines += ["", "-- Interests questions"]
for index, item in enumerate(INTERESTS_QUESTIONS, start=1):
    text, dimension, icon = item
    lines.append(
        "INSERT INTO quiz_questions (category_id, question_text, question_type, dimension, image_icon, is_active, display_order) "
        f"SELECT id, '{esc(text)}', 'likert', '{esc(dimension)}', '{esc(icon)}', 1, {index} "
        "FROM quiz_categories WHERE slug = 'interests';"
    )
    for opt_i, (score, label, mark) in enumerate(LIKERT_LABELS, start=1):
        lines.append(
            "INSERT INTO question_options (question_id, option_text, option_emoji, score_value, dimension, display_order) "
            f"SELECT MAX(id), '{esc(label)}', '{esc(mark)}', {score}, '{esc(dimension)}', {opt_i} FROM quiz_questions;"
        )

lines += ["", "-- Career profiles"]
for career in CAREERS:
    lines.append(
        "INSERT INTO career_profiles (title, summary, strengths_text, growth_text, subjects_text) VALUES ("
        f"'{esc(career['title'])}', '{esc(career['summary'])}', '{esc(career['strengths'])}', "
        f"'{esc(career['growth'])}', '{esc(career['subjects'])}');"
    )
    for trait, weight in career["weights"].items():
        lines.append(
            "INSERT INTO career_profile_weights (career_id, trait_key, weight) "
            f"SELECT MAX(id), '{esc(trait)}', {weight} FROM career_profiles;"
        )

lines += ["", "-- Sample opportunities (not live vacancies)"]
for job in JOBS:
    lines.append(
        "INSERT INTO job_opportunities "
        "(title, organization, city, career_field, required_skills, experience_level, apply_url, is_sample) VALUES ("
        f"'{esc(job[0])}', '{esc(job[1])}', '{esc(job[2])}', '{esc(job[3])}', '{esc(job[4])}', '{esc(job[5])}', '{esc(job[6])}', 1);"
    )

print("\n".join(lines))
