"""
Seed data for Career Compass.

This module stores the demo admin hash, quiz content, career profiles,
and sample job listings. The running app inserts these rows if the
database is empty so a student can start immediately.
"""

from database import execute, fetch_one

# Werkzeug pbkdf2 hash of the demonstration password "Admin123".
# Generated with: generate_password_hash('Admin123', method='pbkdf2:sha256:260000')
ADMIN_PASSWORD_HASH = (
    "pbkdf2:sha256:260000$RGErKjeo6YrYUAXo$"
    "119a12f7910b4f5f0767738d5db1b12928c89645330834dac9691fba7256ab54"
)

LIKERT_LABELS = [
    (1, "Not like me yet", "○"),
    (2, "Rarely like me", "◔"),
    (3, "Sometimes like me", "◑"),
    (4, "Often like me", "◕"),
    (5, "Very much like me", "●"),
]

CATEGORIES = [
    {
        "slug": "personality",
        "name": "Personality",
        "description": "How you move through people, plans, and uncertainty.",
        "accent": "coral",
    },
    {
        "slug": "skills",
        "name": "Skills",
        "description": "What you can already build, explain, and organise.",
        "accent": "teal",
    },
    {
        "slug": "interests",
        "name": "Interests",
        "description": "Topics and settings that naturally hold your attention.",
        "accent": "gold",
    },
]

# Each personality item is a short realistic scene with four meaningful choices.
PERSONALITY_QUESTIONS = [
    {
        "text": "Your group project is stuck. Two teammates disagree, and the deadline is three days away. What do you do first?",
        "dimension": "agreeableness",
        "icon": "people",
        "options": [
            ("Invite both people to map the shared goal before picking a side.", "🤝", 5, "agreeableness"),
            ("Write a clear task list and assign owners so the clock is used well.", "📋", 5, "conscientiousness"),
            ("Suggest a bold new direction that could make the whole piece stronger.", "💡", 5, "openness"),
            ("Speak up in the meeting and keep the energy moving toward a decision.", "🎤", 5, "extraversion"),
        ],
    },
    {
        "text": "You are given a weekend with no homework and no plans. How do you actually spend it?",
        "dimension": "openness",
        "icon": "weekend",
        "options": [
            ("Try a new hobby, neighbourhood, or idea you have never attempted.", "🗺️", 5, "openness"),
            ("Catch up with friends, call people, or join something social.", "☕", 5, "extraversion"),
            ("Tidy unfinished work, plan next week, and feel settled.", "🗂️", 5, "conscientiousness"),
            ("Rest, journal, and recover so Monday does not knock you over.", "🌱", 5, "resilience"),
        ],
    },
    {
        "text": "A teacher offers two versions of an assignment: a proven format with a marking scheme, or an open brief with more risk. You choose…",
        "dimension": "openness",
        "icon": "choice",
        "options": [
            ("The open brief — I like inventing the shape of the work.", "✨", 5, "openness"),
            ("The proven format — I want a clean, reliable result.", "✅", 5, "conscientiousness"),
            ("Whichever version lets me work with classmates.", "👥", 5, "agreeableness"),
            ("Whichever one I can present or perform in front of others.", "🎭", 5, "extraversion"),
        ],
    },
    {
        "text": "It is 10 p.m. and a submission is due at 8 a.m. The file is messy. Your instinct is to…",
        "dimension": "conscientiousness",
        "icon": "deadline",
        "options": [
            ("Make a mini-plan, fix the highest-risk parts, then sleep a little.", "⏱️", 5, "conscientiousness"),
            ("Stay calm, breathe, and work in steady blocks without panic.", "🌊", 5, "resilience"),
            ("Message a teammate and finish the weakest section together.", "💬", 5, "agreeableness"),
            ("Rewrite it in a more original way even if that takes longer.", "🖊️", 5, "openness"),
        ],
    },
    {
        "text": "Your class needs someone to present to the whole school. How does that land with you?",
        "dimension": "extraversion",
        "icon": "stage",
        "options": [
            ("I would volunteer — live rooms give me energy.", "🎤", 5, "extraversion"),
            ("I would help write the script and let a louder person speak.", "📝", 5, "conscientiousness"),
            ("I would join if a friend was on stage with me.", "🙌", 5, "agreeableness"),
            ("I would do it if I had time to practise until I felt steady.", "🎯", 5, "resilience"),
        ],
    },
    {
        "text": "A close friend is upset after a harsh comment from a teacher. You are most likely to…",
        "dimension": "agreeableness",
        "icon": "care",
        "options": [
            ("Sit with them, listen fully, and help them feel less alone.", "💛", 5, "agreeableness"),
            ("Help them draft a calm, practical next step.", "🧭", 5, "conscientiousness"),
            ("Take them out to reset and talk it through in motion.", "🚶", 5, "extraversion"),
            ("Remind them that one comment is not the whole story.", "🌤️", 5, "resilience"),
        ],
    },
    {
        "text": "An assignment is vague: “Create something useful for your community.” There is no rubric yet. You…",
        "dimension": "openness",
        "icon": "fog",
        "options": [
            ("Enjoy the blank page and start sketching unusual ideas.", "🌫️", 5, "openness"),
            ("Ask clarifying questions and build your own checklist.", "📌", 5, "conscientiousness"),
            ("Form a small group so you can think out loud together.", "🔄", 5, "extraversion"),
            ("Start small, test one idea, and adjust if it fails.", "🔁", 5, "resilience"),
        ],
    },
    {
        "text": "A club needs a coordinator for the next month. Nobody else raises a hand. You…",
        "dimension": "extraversion",
        "icon": "lead",
        "options": [
            ("Take the role and get people moving.", "🚩", 5, "extraversion"),
            ("Take it only if the tasks and calendar are clear.", "📆", 5, "conscientiousness"),
            ("Offer to share the role so nobody is left carrying it alone.", "🧩", 5, "agreeableness"),
            ("Take it as practice even if the idea makes you nervous.", "🧗", 5, "resilience"),
        ],
    },
    {
        "text": "You studied hard and still scored lower than expected. The next day you…",
        "dimension": "resilience",
        "icon": "setback",
        "options": [
            ("Name what hurt, then pick one skill to rebuild.", "🧱", 5, "resilience"),
            ("Analyse the paper and make a revision timetable.", "📊", 5, "conscientiousness"),
            ("Talk it through with someone who knows your work.", "🗣️", 5, "agreeableness"),
            ("Try a completely different study method this time.", "🔬", 5, "openness"),
        ],
    },
    {
        "text": "You are planning a class trip. What part do you naturally grab?",
        "dimension": "conscientiousness",
        "icon": "trip",
        "options": [
            ("Budget, timings, and the backup plan if rain appears.", "🌧️", 5, "conscientiousness"),
            ("The unusual stop that nobody else would have suggested.", "📍", 5, "openness"),
            ("Keeping the group included and the mood kind.", "🎈", 5, "agreeableness"),
            ("Ice-breakers, playlists, and getting people talking.", "🎵", 5, "extraversion"),
        ],
    },
    {
        "text": "In a classroom discussion, a view you disagree with is getting applause. You…",
        "dimension": "resilience",
        "icon": "debate",
        "options": [
            ("Stay composed and offer a clear counter-point.", "⚖️", 5, "resilience"),
            ("Ask a genuine question to understand the other side.", "❓", 5, "agreeableness"),
            ("Jump in quickly and keep the debate lively.", "⚡", 5, "extraversion"),
            ("Connect their idea to a surprising example from another field.", "🔗", 5, "openness"),
        ],
    },
    {
        "text": "A teammate is falling behind and the rest of the group is getting impatient. You…",
        "dimension": "agreeableness",
        "icon": "pace",
        "options": [
            ("Check in privately and split the remaining work more fairly.", "🤲", 5, "agreeableness"),
            ("Reset the timeline and make the remaining tasks visible.", "📐", 5, "conscientiousness"),
            ("Call a short huddle so the group can reset together.", "⭕", 5, "extraversion"),
            ("Keep your own focus steady even if the mood is tense.", "🧘", 5, "resilience"),
        ],
    },
]

SKILLS_QUESTIONS = [
    ("I can break a messy problem into smaller pieces and spot patterns in information.", "analytical", "grid"),
    ("I explain ideas so other people actually understand what I mean.", "communication", "talk"),
    ("I am comfortable learning tools, software, or technical systems by experimenting.", "technical", "chip"),
    ("People often look to me when a group needs direction.", "leadership", "flag"),
    ("I enjoy making things that did not exist until I sketched them.", "creativity", "spark"),
    ("When something breaks, I stay with it until I find a workable fix.", "problem_solving", "wrench"),
    ("I notice small errors, missing steps, or details other people skip.", "attention_to_detail", "lens"),
    ("I can compare numbers, charts, or evidence and say what they probably mean.", "analytical", "chart"),
    ("I can write or speak in a structured way for different audiences.", "communication", "pen"),
    ("I pick up new apps, devices, or lab methods faster than most classmates.", "technical", "bolt"),
    ("I can delegate, encourage, and keep a team moving without doing every task myself.", "leadership", "team"),
    ("I combine ideas from different subjects to invent a fresh approach.", "creativity", "blend"),
]

INTERESTS_QUESTIONS = [
    ("Building or understanding how computers, apps, and digital systems work holds my attention.", "technology", "code"),
    ("I lose track of time when I am investigating how something in nature or a lab actually works.", "science", "atom"),
    ("I like the idea of starting projects, selling ideas, or organising people around a goal.", "business", "shop"),
    ("Colour, layout, story, music, or visual making feels like home to me.", "arts", "palette"),
    ("Helping people learn, feel heard, or get through a hard day matters to me.", "social", "heart"),
    ("How bodies work, how people heal, and how health systems run genuinely interests me.", "healthcare", "pulse"),
    ("Rules, fairness, public decisions, and arguing a case from evidence draw me in.", "law", "scales"),
    ("I care about land, climate, water, and how communities live with the living world.", "environment", "leaf"),
    ("I would happily spend extra hours debugging, designing, or exploring a new digital tool.", "technology", "keyboard"),
    ("Reading research, asking ‘why’, and testing a guess feels exciting rather than dry.", "science", "scope"),
    ("I notice design everywhere — posters, apps, rooms — and want to shape how things look and feel.", "arts", "frame"),
    ("I follow news about climate, wildlife, or sustainable cities more than most people my age.", "environment", "globe"),
]


def _likert_options():
    return [
        (score, label, mark, "")
        for score, label, mark in LIKERT_LABELS
    ]


CAREERS = [
    {
        "title": "Software Developer",
        "summary": "You design, write, and improve programs that other people use every day.",
        "strengths": "Logical building, patience with bugs, curiosity about how systems fit together.",
        "growth": "User empathy, documentation, and collaborating across design and product teams.",
        "subjects": "Computer Science, Mathematics, English communication, any design elective.",
        "weights": {
            "technical": 0.95,
            "analytical": 0.85,
            "problem_solving": 0.9,
            "technology": 0.95,
            "attention_to_detail": 0.7,
            "openness": 0.55,
            "conscientiousness": 0.6,
        },
    },
    {
        "title": "Data Analyst",
        "summary": "You turn numbers and messy records into clear pictures that help people decide.",
        "strengths": "Pattern spotting, careful checking, explaining charts in ordinary language.",
        "growth": "Storytelling with data, domain knowledge, and asking the question behind the question.",
        "subjects": "Mathematics, Statistics, Computer Science, Economics, English.",
        "weights": {
            "analytical": 0.95,
            "attention_to_detail": 0.85,
            "technical": 0.7,
            "technology": 0.6,
            "science": 0.55,
            "conscientiousness": 0.75,
            "communication": 0.55,
        },
    },
    {
        "title": "UX/UI Designer",
        "summary": "You shape how a product feels to use — the flow, the screens, the tiny decisions.",
        "strengths": "Visual judgement, empathy for users, iterating from feedback.",
        "growth": "Research methods, accessibility, and partnering with engineers without losing craft.",
        "subjects": "Fine Arts / Design, Computer Science, Psychology, English.",
        "weights": {
            "creativity": 0.95,
            "arts": 0.9,
            "communication": 0.7,
            "agreeableness": 0.55,
            "openness": 0.8,
            "technology": 0.5,
            "attention_to_detail": 0.6,
        },
    },
    {
        "title": "Doctor / Healthcare Professional",
        "summary": "You study the body and walk with people through illness, prevention, and recovery.",
        "strengths": "Steady focus, care for others, comfort with science and long training paths.",
        "growth": "Boundaries, teamwork in hospitals, and communicating clearly under pressure.",
        "subjects": "Biology, Chemistry, Physics, English, a language.",
        "weights": {
            "healthcare": 0.95,
            "science": 0.8,
            "agreeableness": 0.75,
            "attention_to_detail": 0.8,
            "resilience": 0.85,
            "conscientiousness": 0.8,
            "communication": 0.65,
        },
    },
    {
        "title": "Teacher / Counselor",
        "summary": "You help other people learn, grow, and find language for what they are facing.",
        "strengths": "Patience, explanation, reading a room, building trust.",
        "growth": "Classroom systems, assessment design, and looking after your own energy.",
        "subjects": "The subject you love, Psychology, English, a second language.",
        "weights": {
            "social": 0.95,
            "communication": 0.9,
            "agreeableness": 0.85,
            "extraversion": 0.55,
            "resilience": 0.7,
            "leadership": 0.55,
            "conscientiousness": 0.6,
        },
    },
    {
        "title": "Lawyer",
        "summary": "You work with rules, evidence, and argument to help people navigate conflict and rights.",
        "strengths": "Close reading, structured argument, staying calm when stakes are high.",
        "growth": "Listening past the brief, ethics in grey areas, and writing with less jargon.",
        "subjects": "Political Science, History, English, Legal Studies, a language.",
        "weights": {
            "law": 0.95,
            "communication": 0.85,
            "analytical": 0.8,
            "attention_to_detail": 0.75,
            "resilience": 0.65,
            "conscientiousness": 0.7,
            "extraversion": 0.45,
        },
    },
    {
        "title": "Entrepreneur",
        "summary": "You notice a gap, gather people and tools, and try to build something people will use.",
        "strengths": "Initiative, tolerance for uncertainty, selling a story others can join.",
        "growth": "Financial discipline, finishing unglamorous work, and hearing criticism early.",
        "subjects": "Business Studies, Accountancy, Economics, English, any maker elective.",
        "weights": {
            "business": 0.95,
            "leadership": 0.9,
            "extraversion": 0.7,
            "resilience": 0.85,
            "creativity": 0.7,
            "openness": 0.65,
            "communication": 0.7,
        },
    },
    {
        "title": "Environmental Scientist",
        "summary": "You study living systems and help communities make cleaner, wiser choices about land and climate.",
        "strengths": "Field curiosity, scientific patience, care for places bigger than one person.",
        "growth": "Policy literacy, data tools, and explaining science to non-scientists.",
        "subjects": "Biology, Geography, Chemistry, Environmental Science, Mathematics.",
        "weights": {
            "environment": 0.95,
            "science": 0.9,
            "analytical": 0.7,
            "openness": 0.6,
            "conscientiousness": 0.65,
            "social": 0.4,
            "attention_to_detail": 0.6,
        },
    },
    {
        "title": "Research Scientist",
        "summary": "You ask careful questions, design tests, and add a small honest piece to what humans know.",
        "strengths": "Deep focus, comfort with slow progress, love of precision.",
        "growth": "Sharing findings clearly, collaboration, and handling experiments that refuse to work.",
        "subjects": "Physics / Chemistry / Biology, Mathematics, Computer Science, English.",
        "weights": {
            "science": 0.95,
            "analytical": 0.9,
            "attention_to_detail": 0.85,
            "openness": 0.7,
            "conscientiousness": 0.75,
            "technical": 0.55,
            "resilience": 0.65,
        },
    },
    {
        "title": "Digital Marketer",
        "summary": "You help ideas travel — campaigns, content, audiences, and the numbers behind attention.",
        "strengths": "Audience sense, writing or visual punch, reading what a campaign taught you.",
        "growth": "Ethics around persuasion, analytics depth, and patience with unglamorous testing.",
        "subjects": "English, Business Studies, Psychology, Computer Science, Art.",
        "weights": {
            "business": 0.8,
            "communication": 0.9,
            "creativity": 0.75,
            "arts": 0.55,
            "extraversion": 0.6,
            "technology": 0.5,
            "analytical": 0.55,
        },
    },
    {
        "title": "Graphic Designer",
        "summary": "You give ideas a visible form — posters, brands, layouts, motion, and print.",
        "strengths": "Visual craft, taste, turning a brief into something people remember.",
        "growth": "Client communication, version control, and design that also works for accessibility.",
        "subjects": "Fine Arts, Design, English, Computer applications, a language.",
        "weights": {
            "arts": 0.95,
            "creativity": 0.95,
            "attention_to_detail": 0.7,
            "openness": 0.75,
            "communication": 0.5,
            "technology": 0.4,
            "conscientiousness": 0.55,
        },
    },
    {
        "title": "Civil Services / Public Policy Professional",
        "summary": "You work on public problems — policy, administration, and the slow craft of institutions.",
        "strengths": "Wide reading, fairness, stamina for long preparation and complex systems.",
        "growth": "Specialist depth, humility in community work, and writing that ordinary people can use.",
        "subjects": "Political Science, History, Economics, Geography, English, a language.",
        "weights": {
            "law": 0.75,
            "social": 0.8,
            "leadership": 0.7,
            "analytical": 0.7,
            "communication": 0.75,
            "conscientiousness": 0.8,
            "resilience": 0.75,
        },
    },
]

JOBS = [
    ("Junior Web Developer Intern", "Riverleaf Labs", "Bengaluru", "Software Developer", "HTML, Python, Git", "Internship", "#sample"),
    ("Python Programming Intern", "Nimbus School of Code", "Bengaluru", "Software Developer", "Python, problem solving", "Internship", "#sample"),
    ("Data Intern — Public Dashboards", "Civic Numbers Studio", "Bengaluru", "Data Analyst", "Spreadsheets, charts, SQL basics", "Internship", "#sample"),
    ("Junior Data Analyst", "Kaveri Insights", "Bengaluru", "Data Analyst", "Excel, statistics, communication", "Entry", "#sample"),
    ("Product Design Intern", "Palm & Pixel", "Bengaluru", "UX/UI Designer", "Figma, user interviews, visual design", "Internship", "#sample"),
    ("Visual Design Apprentice", "Harbour Type", "Bengaluru", "Graphic Designer", "Layout, typography, Adobe or Figma", "Apprenticeship", "#sample"),
    ("Community Health Volunteer", "South Ridge Clinic Network", "Bengaluru", "Doctor / Healthcare Professional", "Biology, empathy, reliability", "Volunteer", "#sample"),
    ("Science Club Facilitator", "Open Desk Learning", "Bengaluru", "Teacher / Counselor", "Explanation, patience, planning", "Part-time", "#sample"),
    ("Legal Research Intern", "City Rights Collective", "Bengaluru", "Lawyer", "Writing, reading case notes, research", "Internship", "#sample"),
    ("Campus Venture Associate", "Seedbed Circle", "Bengaluru", "Entrepreneur", "Initiative, communication, basic finance", "Part-time", "#sample"),
    ("Field Survey Intern", "Green Canopy Project", "Bengaluru", "Environmental Scientist", "Observation, notes, teamwork", "Internship", "#sample"),
    ("Lab Assistant (After-school)", "Blue Lamp Research Club", "Bengaluru", "Research Scientist", "Careful measurement, lab safety", "Part-time", "#sample"),
    ("Content & Campaign Intern", "Northwind Stories", "Bengaluru", "Digital Marketer", "Writing, social media, analytics basics", "Internship", "#sample"),
    ("Policy Research Intern", "Forum for Civic Design", "Bengaluru", "Civil Services / Public Policy Professional", "Writing, current affairs, analysis", "Internship", "#sample"),
    ("Frontend Intern", "Harbour Apps", "Mumbai", "Software Developer", "JavaScript, UI, Git", "Internship", "#sample"),
    ("UX Research Intern", "Lotus Interface", "Mumbai", "UX/UI Designer", "Interviews, note-taking, curiosity", "Internship", "#sample"),
    ("Hospital Support Intern", "Seaside Medical College", "Chennai", "Doctor / Healthcare Professional", "Biology, communication, punctuality", "Internship", "#sample"),
    ("Classroom Support Fellow", "River School Collective", "Delhi", "Teacher / Counselor", "Facilitation, empathy, planning", "Fellowship", "#sample"),
    ("Junior Graphic Intern", "Indigo Press", "Delhi", "Graphic Designer", "Illustration, layout, deadlines", "Internship", "#sample"),
    ("Climate Data Intern", "Deccan Earth Desk", "Hyderabad", "Environmental Scientist", "Spreadsheets, geography, writing", "Internship", "#sample"),
    ("Startup Operations Intern", "Pune Foundry", "Pune", "Entrepreneur", "Coordination, tools, customer chats", "Internship", "#sample"),
    ("Remote Data Cleaning Intern", "Plaintable Cooperative", "Remote", "Data Analyst", "Attention to detail, spreadsheets", "Internship", "#sample"),
    ("Remote Open-source Contributor", "Compass Forge", "Remote", "Software Developer", "Git, Python or JavaScript, reading docs", "Volunteer", "#sample"),
    ("Moot Court Prep Volunteer", "Just Argument Society", "Kolkata", "Lawyer", "Public speaking, research, teamwork", "Volunteer", "#sample"),
]


def _insert_question(category_id, text, qtype, dimension, icon, order, options):
    qid = execute(
        """
        INSERT INTO quiz_questions
            (category_id, question_text, question_type, dimension, image_icon, is_active, display_order)
        VALUES (?, ?, ?, ?, ?, 1, ?)
        """,
        (category_id, text, qtype, dimension, icon, order),
    )
    for index, option in enumerate(options, start=1):
        option_text, emoji, score, dim = option
        execute(
            """
            INSERT INTO question_options
                (question_id, option_text, option_emoji, score_value, dimension, display_order)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (qid, option_text, emoji, score, dim or dimension, index),
        )
    return qid


def seed_all():
    """Insert categories, questions, careers, weights, and sample jobs."""
    category_ids = {}
    for cat in CATEGORIES:
        existing = fetch_one("SELECT id FROM quiz_categories WHERE slug = ?", (cat["slug"],))
        if existing:
            category_ids[cat["slug"]] = existing["id"]
            continue
        cid = execute(
            """
            INSERT INTO quiz_categories (slug, name, description, accent)
            VALUES (?, ?, ?, ?)
            """,
            (cat["slug"], cat["name"], cat["description"], cat["accent"]),
        )
        category_ids[cat["slug"]] = cid

    if not fetch_one("SELECT id FROM quiz_questions LIMIT 1"):
        for index, item in enumerate(PERSONALITY_QUESTIONS, start=1):
            _insert_question(
                category_ids["personality"],
                item["text"],
                "scenario",
                item["dimension"],
                item["icon"],
                index,
                item["options"],
            )

        for index, item in enumerate(SKILLS_QUESTIONS, start=1):
            text, dimension, icon = item
            options = [(label, mark, score, dimension) for score, label, mark in LIKERT_LABELS]
            _insert_question(
                category_ids["skills"],
                text,
                "likert",
                dimension,
                icon,
                index,
                options,
            )

        for index, item in enumerate(INTERESTS_QUESTIONS, start=1):
            text, dimension, icon = item
            options = [(label, mark, score, dimension) for score, label, mark in LIKERT_LABELS]
            _insert_question(
                category_ids["interests"],
                text,
                "likert",
                dimension,
                icon,
                index,
                options,
            )

    if not fetch_one("SELECT id FROM career_profiles LIMIT 1"):
        for career in CAREERS:
            cid = execute(
                """
                INSERT INTO career_profiles (title, summary, strengths_text, growth_text, subjects_text)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    career["title"],
                    career["summary"],
                    career["strengths"],
                    career["growth"],
                    career["subjects"],
                ),
            )
            for trait, weight in career["weights"].items():
                execute(
                    """
                    INSERT INTO career_profile_weights (career_id, trait_key, weight)
                    VALUES (?, ?, ?)
                    """,
                    (cid, trait, weight),
                )

    if not fetch_one("SELECT id FROM job_opportunities LIMIT 1"):
        for job in JOBS:
            execute(
                """
                INSERT INTO job_opportunities
                    (title, organization, city, career_field, required_skills, experience_level, apply_url, is_sample)
                VALUES (?, ?, ?, ?, ?, ?, ?, 1)
                """,
                job,
            )


def ensure_admin_hash_matches():
    """Helper used by tests — returns the seeded admin row if present."""
    return fetch_one("SELECT id, username, password_hash FROM admins WHERE username = ?", ("Admin",))
