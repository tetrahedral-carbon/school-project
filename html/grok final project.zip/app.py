"""
Career Compass — Flask application.

A Class 12-friendly career guidance site:
register → three quizzes with auto-save → results, charts, sample jobs, PDF.

Comments are written so a student can explain the flow in a viva.
"""

from __future__ import annotations

import json
import re
import secrets
import time
from datetime import datetime
from functools import wraps
from collections import defaultdict

from flask import (
    Flask,
    Response,
    abort,
    flash,
    g,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash

from config import Config
from database import execute, fetch_all, fetch_one, init_db
from pdf_service import build_report_pdf
from scoring import (
    TRAIT_LABELS,
    build_full_report,
    profile_summary,
    save_quiz_result,
    score_attempt,
)

USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,20}$")
PASSWORD_RE = re.compile(r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$")

# Simple in-memory rate limit: {ip: [timestamps]}
_login_hits = defaultdict(list)

QUOTES = [
    "Direction is a skill you can practise.",
    "A hunch is a starting point, not a verdict.",
    "Curiosity is already a compass.",
    "Your next step does not have to be your last one.",
    "Patterns show up when you pay attention.",
    "Maps are useful. They are not the land itself.",
]


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    app.secret_key = Config.SECRET_KEY
    app.config["SESSION_COOKIE_HTTPONLY"] = Config.SESSION_COOKIE_HTTPONLY
    app.config["SESSION_COOKIE_SAMESITE"] = Config.SESSION_COOKIE_SAMESITE
    app.config["SESSION_COOKIE_SECURE"] = Config.SESSION_COOKIE_SECURE

    with app.app_context():
        init_db()

    @app.before_request
    def _csrf_and_user():
        if "csrf_token" not in session:
            session["csrf_token"] = secrets.token_hex(16)
        g.csrf_token = session["csrf_token"]
        g.user = current_user()
        g.admin = current_admin()
        if request.method in ("POST", "PUT", "DELETE"):
            token = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token")
            if token != session.get("csrf_token"):
                if request.is_json or request.headers.get("X-Requested-With") == "XMLHttpRequest":
                    return jsonify({"ok": False, "error": "Session expired. Refresh and try again."}), 400
                flash("Your session token expired. Please try again.", "error")
                return redirect(request.referrer or url_for("home"))

    @app.context_processor
    def _inject():
        return {
            "csrf_token": session.get("csrf_token", ""),
            "current_user": g.get("user"),
            "current_admin": g.get("admin"),
            "app_name": Config.APP_NAME,
            "tagline": Config.TAGLINE,
            "quote": QUOTES[int(time.time() / 17) % len(QUOTES)],
            "year": datetime.now().year,
        }

    # ----- helpers -----

    def current_user():
        user_id = session.get("user_id")
        if not user_id:
            return None
        return fetch_one("SELECT * FROM users WHERE id = ?", (user_id,))

    def current_admin():
        admin_id = session.get("admin_id")
        if not admin_id:
            return None
        return fetch_one("SELECT * FROM admins WHERE id = ?", (admin_id,))

    def login_required(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not current_user():
                flash("Please sign in to continue your path.", "info")
                return redirect(url_for("login", next=request.path))
            return view(*args, **kwargs)

        return wrapped

    def admin_required(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not current_admin():
                flash("Admin access only.", "error")
                return redirect(url_for("admin_login"))
            return view(*args, **kwargs)

        return wrapped

    def too_many_logins():
        ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown").split(",")[0].strip()
        now = time.time()
        window = Config.LOGIN_WINDOW_SECONDS
        hits = [t for t in _login_hits[ip] if now - t < window]
        _login_hits[ip] = hits
        if len(hits) >= Config.LOGIN_MAX_ATTEMPTS:
            return True
        _login_hits[ip].append(now)
        return False

    def get_category(slug):
        row = fetch_one("SELECT * FROM quiz_categories WHERE slug = ?", (slug,))
        if not row:
            abort(404)
        return row

    def active_questions(category_id):
        return fetch_all(
            """
            SELECT * FROM quiz_questions
            WHERE category_id = ? AND is_active = 1
            ORDER BY display_order ASC, id ASC
            """,
            (category_id,),
        )

    def options_for(question_id):
        return fetch_all(
            """
            SELECT * FROM question_options
            WHERE question_id = ?
            ORDER BY display_order ASC, id ASC
            """,
            (question_id,),
        )

    def latest_attempt(user_id, category_id):
        return fetch_one(
            """
            SELECT * FROM quiz_attempts
            WHERE user_id = ? AND category_id = ?
            ORDER BY id DESC LIMIT 1
            """,
            (user_id, category_id),
        )

    def attempt_progress(user_id, category_id):
        questions = active_questions(category_id)
        total = len(questions)
        attempt = latest_attempt(user_id, category_id)
        if not attempt:
            return {"status": "not_started", "percent": 0, "answered": 0, "total": total, "attempt": None}
        answers = fetch_all(
            "SELECT question_id FROM user_answers WHERE attempt_id = ?",
            (attempt["id"],),
        )
        answered = len(answers)
        percent = int(round(100 * answered / total)) if total else 0
        return {
            "status": attempt["status"],
            "percent": percent,
            "answered": answered,
            "total": total,
            "attempt": attempt,
        }

    def validate_username(username):
        if not USERNAME_RE.match(username or ""):
            return "Username must be 3–20 characters using letters, numbers, or underscores."
        return None

    def validate_password(password):
        if not PASSWORD_RE.match(password or ""):
            return "Password needs 8+ characters with uppercase, lowercase, and a number."
        return None

    def audit(action, details=""):
        admin = current_admin()
        if not admin:
            return
        execute(
            "INSERT INTO admin_audit_logs (admin_id, action, details) VALUES (?, ?, ?)",
            (admin["id"], action, details),
        )

    # ----- public pages -----

    @app.route("/")
    def home():
        if current_user():
            return redirect(url_for("dashboard"))
        if current_admin():
            return redirect(url_for("admin_dashboard"))
        return render_template("login.html", mode="login")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if current_user():
            return redirect(url_for("dashboard"))
        if request.method == "POST":
            if too_many_logins():
                flash("Too many sign-in tries. Wait a few minutes and try again.", "error")
                return render_template("login.html", mode="login"), 429
            username = (request.form.get("username") or "").strip()
            password = request.form.get("password") or ""
            user = fetch_one("SELECT * FROM users WHERE username = ?", (username,))
            if not user or not check_password_hash(user["password_hash"], password):
                flash("That username and password do not match our records.", "error")
                return render_template("login.html", mode="login"), 401
            session.clear()
            session["user_id"] = user["id"]
            session["csrf_token"] = secrets.token_hex(16)
            flash(f"Welcome back, {user['full_name'].split()[0]}.", "success")
            nxt = request.args.get("next") or url_for("dashboard")
            if not nxt.startswith("/"):
                nxt = url_for("dashboard")
            return redirect(nxt)
        return render_template("login.html", mode="login")

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if current_user():
            return redirect(url_for("dashboard"))
        if request.method == "POST":
            username = (request.form.get("username") or "").strip()
            password = request.form.get("password") or ""
            confirm = request.form.get("confirm") or ""
            full_name = (request.form.get("full_name") or "").strip()
            city = (request.form.get("city") or "Bengaluru").strip() or "Bengaluru"
            hunch = (request.form.get("career_hunch") or "").strip()
            error = validate_username(username) or validate_password(password)
            if not full_name or len(full_name) < 2:
                error = error or "Please enter the name you would like us to use."
            if password != confirm:
                error = error or "The two passwords do not match."
            if fetch_one("SELECT id FROM users WHERE username = ?", (username,)):
                error = error or "That username is already taken. Try another."
            if error:
                flash(error, "error")
                return render_template("register.html"), 400
            user_id = execute(
                """
                INSERT INTO users (username, password_hash, full_name, city, career_hunch)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    username,
                    generate_password_hash(password, method=Config.PASSWORD_HASH_METHOD),
                    full_name[:80],
                    city[:80],
                    hunch[:200],
                ),
            )
            session.clear()
            session["user_id"] = user_id
            session["csrf_token"] = secrets.token_hex(16)
            flash("Your compass is set. Start with any quiz — you can pause whenever you need.", "success")
            return redirect(url_for("dashboard"))
        return render_template("register.html")

    @app.route("/logout")
    def logout():
        session.clear()
        flash("Signed out. Your saved answers are waiting when you return.", "info")
        return redirect(url_for("home"))

    # ----- student workspace -----

    @app.route("/dashboard")
    @login_required
    def dashboard():
        user = current_user()
        cards = []
        for slug in ("personality", "skills", "interests"):
            category = get_category(slug)
            progress = attempt_progress(user["id"], category["id"])
            cards.append({"category": category, "progress": progress})
        completed = [card for card in cards if card["progress"]["status"] == "completed"]
        return render_template(
            "dashboard.html",
            cards=cards,
            all_done=len(completed) == 3,
            user=user,
        )

    @app.route("/profile", methods=["POST"])
    @login_required
    def update_profile():
        user = current_user()
        city = (request.form.get("city") or user["city"] or "Bengaluru").strip()[:80]
        hunch = (request.form.get("career_hunch") or "").strip()[:200]
        execute(
            "UPDATE users SET city = ?, career_hunch = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            (city, hunch, user["id"]),
        )
        flash("Profile updated.", "success")
        return redirect(url_for("dashboard"))

    # ----- quizzes -----

    @app.route("/quiz/<quiz_type>/start")
    @login_required
    def quiz_start(quiz_type):
        user = current_user()
        category = get_category(quiz_type)
        questions = active_questions(category["id"])
        if not questions:
            flash("This quiz has no active questions yet.", "error")
            return redirect(url_for("dashboard"))
        attempt = latest_attempt(user["id"], category["id"])
        if attempt and attempt["status"] in ("in_progress", "paused"):
            index = int(attempt["current_index"] or 0) + 1
            return redirect(url_for("quiz_question", quiz_type=quiz_type, question_number=index))
        attempt_id = execute(
            """
            INSERT INTO quiz_attempts (user_id, category_id, status, current_index)
            VALUES (?, ?, 'in_progress', 0)
            """,
            (user["id"], category["id"]),
        )
        return redirect(url_for("quiz_intro", quiz_type=quiz_type, attempt_id=attempt_id))

    @app.route("/quiz/<quiz_type>/intro")
    @login_required
    def quiz_intro(quiz_type):
        category = get_category(quiz_type)
        questions = active_questions(category["id"])
        return render_template(
            "quiz_intro.html",
            category=category,
            total=len(questions),
        )

    @app.route("/quiz/<quiz_type>/resume")
    @login_required
    def quiz_resume(quiz_type):
        user = current_user()
        category = get_category(quiz_type)
        attempt = latest_attempt(user["id"], category["id"])
        if not attempt:
            return redirect(url_for("quiz_start", quiz_type=quiz_type))
        if attempt["status"] == "completed":
            return redirect(url_for("dashboard"))
        execute(
            "UPDATE quiz_attempts SET status = 'in_progress', paused_at = NULL WHERE id = ?",
            (attempt["id"],),
        )
        index = int(attempt["current_index"] or 0) + 1
        return redirect(url_for("quiz_question", quiz_type=quiz_type, question_number=index))

    @app.route("/quiz/<quiz_type>/pause", methods=["POST", "GET"])
    @login_required
    def quiz_pause(quiz_type):
        user = current_user()
        category = get_category(quiz_type)
        attempt = latest_attempt(user["id"], category["id"])
        if attempt and attempt["status"] != "completed":
            execute(
                "UPDATE quiz_attempts SET status = 'paused', paused_at = CURRENT_TIMESTAMP WHERE id = ?",
                (attempt["id"],),
            )
        return render_template("quiz_paused.html", category=category)

    @app.route("/quiz/<quiz_type>/question/<int:question_number>", methods=["GET", "POST"])
    @login_required
    def quiz_question(quiz_type, question_number):
        user = current_user()
        category = get_category(quiz_type)
        questions = active_questions(category["id"])
        total = len(questions)
        if total == 0:
            abort(404)
        question_number = max(1, min(question_number, total))
        attempt = latest_attempt(user["id"], category["id"])
        if not attempt or attempt["status"] == "completed":
            return redirect(url_for("quiz_start", quiz_type=quiz_type))

        question = questions[question_number - 1]
        options = options_for(question["id"])
        saved = fetch_one(
            "SELECT * FROM user_answers WHERE attempt_id = ? AND question_id = ?",
            (attempt["id"], question["id"]),
        )

        if request.method == "POST":
            option_id = request.form.get("option_id", type=int)
            chosen = next((opt for opt in options if opt["id"] == option_id), None)
            if not chosen:
                flash("Please choose an answer to continue.", "error")
                return redirect(
                    url_for("quiz_question", quiz_type=quiz_type, question_number=question_number)
                )
            existing = saved
            if existing:
                execute(
                    """
                    UPDATE user_answers
                    SET option_id = ?, score_value = ?, answered_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,
                    (chosen["id"], chosen["score_value"], existing["id"]),
                )
            else:
                execute(
                    """
                    INSERT INTO user_answers (attempt_id, question_id, option_id, score_value)
                    VALUES (?, ?, ?, ?)
                    """,
                    (attempt["id"], question["id"], chosen["id"], chosen["score_value"]),
                )
            execute(
                "UPDATE quiz_attempts SET current_index = ?, status = 'in_progress' WHERE id = ?",
                (question_number - 1, attempt["id"]),
            )
            action = request.form.get("action") or "next"
            if action == "pause":
                return redirect(url_for("quiz_pause", quiz_type=quiz_type))
            if action == "back":
                prev_n = max(1, question_number - 1)
                return redirect(url_for("quiz_question", quiz_type=quiz_type, question_number=prev_n))
            if question_number >= total:
                return redirect(url_for("quiz_review", quiz_type=quiz_type))
            return redirect(
                url_for("quiz_question", quiz_type=quiz_type, question_number=question_number + 1)
            )

        answered_ids = {
            row["question_id"]
            for row in fetch_all(
                "SELECT question_id FROM user_answers WHERE attempt_id = ?",
                (attempt["id"],),
            )
        }
        return render_template(
            "quiz_question.html",
            category=category,
            question=question,
            options=options,
            saved=saved,
            number=question_number,
            total=total,
            percent=int(round(100 * (question_number - 1) / total)) if total else 0,
            answered_ids=answered_ids,
            questions=questions,
        )

    @app.route("/quiz/<quiz_type>/save-answer", methods=["POST"])
    @login_required
    def quiz_save_answer(quiz_type):
        """AJAX auto-save used by quiz.js — same rules as the form post."""
        user = current_user()
        category = get_category(quiz_type)
        attempt = latest_attempt(user["id"], category["id"])
        if not attempt or attempt["status"] == "completed":
            return jsonify({"ok": False, "error": "No active attempt"}), 400
        option_id = request.form.get("option_id", type=int)
        question_id = request.form.get("question_id", type=int)
        option = fetch_one(
            "SELECT * FROM question_options WHERE id = ? AND question_id = ?",
            (option_id, question_id),
        )
        if not option:
            return jsonify({"ok": False, "error": "Unknown option"}), 400
        existing = fetch_one(
            "SELECT id FROM user_answers WHERE attempt_id = ? AND question_id = ?",
            (attempt["id"], question_id),
        )
        if existing:
            execute(
                """
                UPDATE user_answers
                SET option_id = ?, score_value = ?, answered_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                (option["id"], option["score_value"], existing["id"]),
            )
        else:
            execute(
                """
                INSERT INTO user_answers (attempt_id, question_id, option_id, score_value)
                VALUES (?, ?, ?, ?)
                """,
                (attempt["id"], question_id, option["id"], option["score_value"]),
            )
        return jsonify({"ok": True})

    @app.route("/quiz/<quiz_type>/review")
    @login_required
    def quiz_review(quiz_type):
        user = current_user()
        category = get_category(quiz_type)
        questions = active_questions(category["id"])
        attempt = latest_attempt(user["id"], category["id"])
        if not attempt:
            return redirect(url_for("quiz_start", quiz_type=quiz_type))
        answers = {
            row["question_id"]: row
            for row in fetch_all(
                "SELECT * FROM user_answers WHERE attempt_id = ?",
                (attempt["id"],),
            )
        }
        unanswered = [q for q in questions if q["id"] not in answers]
        return render_template(
            "quiz_review.html",
            category=category,
            questions=questions,
            answers=answers,
            unanswered=unanswered,
        )

    @app.route("/quiz/<quiz_type>/complete", methods=["POST"])
    @login_required
    def quiz_complete(quiz_type):
        user = current_user()
        category = get_category(quiz_type)
        questions = active_questions(category["id"])
        attempt = latest_attempt(user["id"], category["id"])
        if not attempt:
            return redirect(url_for("quiz_start", quiz_type=quiz_type))
        answers = fetch_all(
            "SELECT question_id FROM user_answers WHERE attempt_id = ?",
            (attempt["id"],),
        )
        if len(answers) < len(questions):
            flash("A few questions are still open. Jump to them from the review list.", "info")
            return redirect(url_for("quiz_review", quiz_type=quiz_type))
        execute(
            """
            UPDATE quiz_attempts
            SET status = 'completed', completed_at = CURRENT_TIMESTAMP, current_index = ?
            WHERE id = ?
            """,
            (len(questions) - 1, attempt["id"]),
        )
        scores = score_attempt(attempt["id"])
        save_quiz_result(user["id"], attempt["id"], category["id"], scores)
        flash(f"{category['name']} chapter complete. Your answers are stored as a new record.", "success")
        return redirect(url_for("dashboard"))

    @app.route("/quiz/<quiz_type>/retake")
    @login_required
    def quiz_retake(quiz_type):
        """Start a brand-new attempt. Older results are never overwritten."""
        user = current_user()
        category = get_category(quiz_type)
        execute(
            """
            INSERT INTO quiz_attempts (user_id, category_id, status, current_index)
            VALUES (?, ?, 'in_progress', 0)
            """,
            (user["id"], category["id"]),
        )
        return redirect(url_for("quiz_intro", quiz_type=quiz_type))

    # ----- results -----

    @app.route("/results")
    @login_required
    def results():
        user = current_user()
        report = build_full_report(user)
        summary = profile_summary(user, report)
        reflection = fetch_one(
            "SELECT * FROM user_reflections WHERE user_id = ? ORDER BY id DESC LIMIT 1",
            (user["id"],),
        )
        return render_template(
            "results.html",
            user=user,
            report=report,
            summary=summary,
            reflection=reflection,
            trait_labels=TRAIT_LABELS,
        )

    @app.route("/results/reflect", methods=["POST"])
    @login_required
    def save_reflection():
        user = current_user()
        note = (request.form.get("note") or "").strip()[:2000]
        if note:
            execute(
                "INSERT INTO user_reflections (user_id, note) VALUES (?, ?)",
                (user["id"], note),
            )
            flash("Reflection saved.", "success")
        return redirect(url_for("results"))

    @app.route("/download-report")
    @login_required
    def download_report():
        user = current_user()
        report = build_full_report(user)
        if not report["complete"]:
            flash("Finish all three quizzes before downloading the full report.", "info")
            return redirect(url_for("results"))
        pdf = build_report_pdf(user, report)
        filename = f"career-compass-{user['username']}.pdf"
        return Response(
            pdf.getvalue(),
            mimetype="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )

    # ----- admin -----

    @app.route("/admin/login", methods=["GET", "POST"])
    def admin_login():
        if current_admin():
            return redirect(url_for("admin_dashboard"))
        if request.method == "POST":
            if too_many_logins():
                flash("Too many attempts. Please wait and try again.", "error")
                return render_template("admin_login.html"), 429
            username = (request.form.get("username") or "").strip()
            password = request.form.get("password") or ""
            admin = fetch_one("SELECT * FROM admins WHERE username = ?", (username,))
            if not admin or not check_password_hash(admin["password_hash"], password):
                flash("Admin credentials were not recognised.", "error")
                return render_template("admin_login.html"), 401
            session.clear()
            session["admin_id"] = admin["id"]
            session["csrf_token"] = secrets.token_hex(16)
            flash("Admin console unlocked.", "success")
            return redirect(url_for("admin_dashboard"))
        return render_template("admin_login.html")

    @app.route("/admin/logout")
    def admin_logout():
        session.clear()
        return redirect(url_for("admin_login"))

    @app.route("/admin/dashboard")
    @admin_required
    def admin_dashboard():
        stats = {
            "users": fetch_one("SELECT COUNT(*) AS n FROM users")["n"],
            "questions": fetch_one("SELECT COUNT(*) AS n FROM quiz_questions")["n"],
            "attempts": fetch_one("SELECT COUNT(*) AS n FROM quiz_attempts")["n"],
            "completed": fetch_one("SELECT COUNT(*) AS n FROM quiz_attempts WHERE status = 'completed'")["n"],
        }
        recent = fetch_all(
            "SELECT * FROM admin_audit_logs ORDER BY id DESC LIMIT 8"
        )
        categories = fetch_all("SELECT * FROM quiz_categories ORDER BY id")
        return render_template(
            "admin_dashboard.html",
            stats=stats,
            recent=recent,
            categories=categories,
        )

    @app.route("/admin/questions")
    @admin_required
    def admin_questions():
        slug = request.args.get("category") or ""
        categories = fetch_all("SELECT * FROM quiz_categories ORDER BY id")
        sql = """
            SELECT q.*, c.slug, c.name AS category_name
            FROM quiz_questions q
            JOIN quiz_categories c ON c.id = q.category_id
        """
        params = []
        if slug:
            sql += " WHERE c.slug = ?"
            params.append(slug)
        sql += " ORDER BY c.id, q.display_order, q.id"
        questions = fetch_all(sql, params)
        return render_template(
            "admin_questions.html",
            questions=questions,
            categories=categories,
            current_slug=slug,
        )

    def _save_question_from_form(question_id=None):
        category_id = request.form.get("category_id", type=int)
        text = (request.form.get("question_text") or "").strip()
        qtype = request.form.get("question_type") or "likert"
        dimension = (request.form.get("dimension") or "openness").strip()
        icon = (request.form.get("image_icon") or "").strip()
        active = 1 if request.form.get("is_active") == "1" else 0
        order = request.form.get("display_order", type=int) or 0
        if not text or not category_id:
            return None, "Question text and category are required."
        if question_id:
            execute(
                """
                UPDATE quiz_questions
                SET category_id=?, question_text=?, question_type=?, dimension=?,
                    image_icon=?, is_active=?, display_order=?, updated_at=CURRENT_TIMESTAMP
                WHERE id=?
                """,
                (category_id, text, qtype, dimension, icon, active, order, question_id),
            )
            qid = question_id
            execute("DELETE FROM question_options WHERE question_id = ?", (qid,))
        else:
            qid = execute(
                """
                INSERT INTO quiz_questions
                    (category_id, question_text, question_type, dimension, image_icon, is_active, display_order)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (category_id, text, qtype, dimension, icon, active, order),
            )
        option_texts = request.form.getlist("option_text[]")
        option_emojis = request.form.getlist("option_emoji[]")
        option_scores = request.form.getlist("option_score[]")
        option_dims = request.form.getlist("option_dimension[]")
        saved_any = False
        for index, opt_text in enumerate(option_texts):
            opt_text = (opt_text or "").strip()
            if not opt_text:
                continue
            emoji = option_emojis[index] if index < len(option_emojis) else ""
            try:
                score = int(option_scores[index]) if index < len(option_scores) else 3
            except ValueError:
                score = 3
            dim = option_dims[index] if index < len(option_dims) else dimension
            execute(
                """
                INSERT INTO question_options
                    (question_id, option_text, option_emoji, score_value, dimension, display_order)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (qid, opt_text, emoji, score, dim, index + 1),
            )
            saved_any = True
        if not saved_any:
            return qid, "Add at least one answer option."
        return qid, None

    @app.route("/admin/questions/add", methods=["GET", "POST"])
    @admin_required
    def admin_questions_add():
        categories = fetch_all("SELECT * FROM quiz_categories ORDER BY id")
        if request.method == "POST":
            qid, error = _save_question_from_form()
            if error:
                flash(error, "error")
                return render_template(
                    "admin_question_form.html",
                    categories=categories,
                    question=None,
                    options=[],
                    trait_labels=TRAIT_LABELS,
                )
            audit("add_question", f"question_id={qid}")
            flash("Question added. It will appear in the student quiz immediately.", "success")
            return redirect(url_for("admin_questions"))
        return render_template(
            "admin_question_form.html",
            categories=categories,
            question=None,
            options=[],
            trait_labels=TRAIT_LABELS,
        )

    @app.route("/admin/questions/edit/<int:question_id>", methods=["GET", "POST"])
    @admin_required
    def admin_questions_edit(question_id):
        question = fetch_one("SELECT * FROM quiz_questions WHERE id = ?", (question_id,))
        if not question:
            abort(404)
        categories = fetch_all("SELECT * FROM quiz_categories ORDER BY id")
        if request.method == "POST":
            _, error = _save_question_from_form(question_id)
            if error:
                flash(error, "error")
            else:
                audit("edit_question", f"question_id={question_id}")
                flash("Question updated.", "success")
                return redirect(url_for("admin_questions"))
        options = options_for(question_id)
        return render_template(
            "admin_question_form.html",
            categories=categories,
            question=question,
            options=options,
            trait_labels=TRAIT_LABELS,
        )

    @app.route("/admin/questions/delete/<int:question_id>", methods=["POST"])
    @admin_required
    def admin_questions_delete(question_id):
        question = fetch_one("SELECT * FROM quiz_questions WHERE id = ?", (question_id,))
        if not question:
            abort(404)
        execute("DELETE FROM question_options WHERE question_id = ?", (question_id,))
        execute("DELETE FROM quiz_questions WHERE id = ?", (question_id,))
        audit("delete_question", f"question_id={question_id}")
        flash("Question deleted.", "success")
        return redirect(url_for("admin_questions"))

    # ----- errors -----

    @app.errorhandler(404)
    def not_found(_e):
        return render_template("error.html", code=404, message="That page is not on this map."), 404

    @app.errorhandler(500)
    def server_error(_e):
        return render_template("error.html", code=500, message="Something went off-course. Try again."), 500

    return app


app = create_app()


if __name__ == "__main__":
    app.run(host=Config.HOST, port=Config.PORT, debug=Config.DEBUG, threaded=True)
