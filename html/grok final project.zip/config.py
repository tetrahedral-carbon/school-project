"""
Career Compass configuration.
Values are read from environment variables so secrets never live in source code.
"""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / "instance"
INSTANCE_DIR.mkdir(exist_ok=True)


def env(name, default=""):
    """Read an environment variable with a fallback default."""
    value = os.environ.get(name)
    if value is None or value == "":
        return default
    return value


class Config:
    """Flask and database settings used by the whole project."""

    SECRET_KEY = env("SECRET_KEY", "career-compass-dev-key-change-in-production")
    APP_NAME = "Career Compass"
    TAGLINE = "Discover your direction. Design your future."

    # Password hashing — pbkdf2 is built into Werkzeug and easy to explain.
    PASSWORD_HASH_METHOD = "pbkdf2:sha256:260000"

    # Session cookie flags. Secure is off in local HTTP preview, on in HTTPS.
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = env("SESSION_COOKIE_SECURE", "0") == "1"

    # Database: MySQL when MYSQL_HOST is set, otherwise local SQLite.
    MYSQL_HOST = env("MYSQL_HOST", "")
    MYSQL_PORT = int(env("MYSQL_PORT", "3306"))
    MYSQL_USER = env("MYSQL_USER", "root")
    MYSQL_PASSWORD = env("MYSQL_PASSWORD", "")
    MYSQL_DATABASE = env("MYSQL_DATABASE", "career_compass_db")
    SQLITE_PATH = env("SQLITE_PATH", str(INSTANCE_DIR / "career_compass.db"))

    # Demo admin (hashed in the database, never stored as plain text).
    ADMIN_USERNAME = env("ADMIN_USERNAME", "Admin")
    ADMIN_PASSWORD = env("ADMIN_PASSWORD", "Admin123")

    # Optional live jobs API placeholder — unused unless a key is provided.
    JOBS_API_KEY = env("JOBS_API_KEY", "")
    AI_API_KEY = env("AI_API_KEY", "")

    # Login rate limit
    LOGIN_MAX_ATTEMPTS = 8
    LOGIN_WINDOW_SECONDS = 600

    DEBUG = env("FLASK_DEBUG", "0") == "1"
    HOST = env("FLASK_HOST", "0.0.0.0")
    PORT = int(env("FLASK_PORT", "8080"))
