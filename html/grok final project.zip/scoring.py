"""
Transparent career scoring and recommendation engine.

No paid AI API is required. Scores are averages of the answers a student
gave, scaled from 1–5 into 0–100. Career match scores are a weighted
overlap between the student's profile and each career's trait weights.
"""

from __future__ import annotations

import json
from collections import defaultdict

from database import execute, fetch_all, fetch_one

TRAIT_LABELS = {
    "openness": "Curiosity & originality",
    "conscientiousness": "Organisation",
    "extraversion": "Communication energy",
    "agreeableness": "Teamwork",
    "resilience": "Adaptability",
    "analytical": "Analytical thinking",
    "communication": "Communication",
    "technical": "Technical ability",
    "leadership": "Leadership",
    "creativity": "Creativity",
    "problem_solving": "Problem-solving",
    "attention_to_detail": "Attention to detail",
    "technology": "Technology",
    "science": "Science & research",
    "business": "Business",
    "arts": "Arts & design",
    "social": "Social service",
    "healthcare": "Healthcare",
    "law": "Law & public service",
    "environment": "Environment",
}

RADAR_KEYS = [
    "creativity",
    "analytical",
    "communication",
    "leadership",
    "technical",
    "agreeableness",
    "resilience",
    "conscientiousness",
]

RADAR_CHART_LABELS = [
    "Creativity",
    "Analytical thinking",
    "Communication",
    "Leadership",
    "Technical ability",
    "Teamwork",
    "Adaptability",
    "Organisation",
]


def score_attempt(attempt_id):
    """Return {dimension: 0-100} for one completed or in-progress attempt."""
    rows = fetch_all(
        """
        SELECT ua.score_value, ua.option_id, qo.dimension AS option_dim,
               q.dimension AS question_dim, q.question_type
        FROM user_answers ua
        JOIN question_options qo ON qo.id = ua.option_id
        JOIN quiz_questions q ON q.id = ua.question_id
        WHERE ua.attempt_id = ?
        """,
        (attempt_id,),
    )
    buckets = defaultdict(list)
    for row in rows:
        dimension = row["option_dim"] or row["question_dim"]
        buckets[dimension].append(int(row["score_value"]))
    return {
        key: round(sum(values) / len(values) / 5 * 100, 1)
        for key, values in buckets.items()
        if values
    }


def save_quiz_result(user_id, attempt_id, category_id, scores):
    execute(
        """
        INSERT INTO quiz_results (user_id, attempt_id, category_id, scores_json)
        VALUES (?, ?, ?, ?)
        """,
        (user_id, attempt_id, category_id, json.dumps(scores)),
    )


def latest_completed_scores(user_id):
    """Merge scores from the latest completed attempt of each quiz category."""
    attempts = fetch_all(
        """
        SELECT qa.id, qa.category_id, qc.slug
        FROM quiz_attempts qa
        JOIN quiz_categories qc ON qc.id = qa.category_id
        WHERE qa.user_id = ? AND qa.status = 'completed'
        ORDER BY qa.completed_at DESC
        """,
        (user_id,),
    )
    seen = set()
    merged = {}
    by_slug = {}
    for attempt in attempts:
        slug = attempt["slug"]
        if slug in seen:
            continue
        seen.add(slug)
        scores = score_attempt(attempt["id"])
        merged.update(scores)
        by_slug[slug] = scores
    return merged, by_slug, sorted(seen)


def match_careers(user_scores, limit=5):
    """
    Weighted overlap:
        match = 100 * sum(user[trait] * weight) / (sum(weight) * 100)
    Missing traits count as 35 (a gentle middle) so one blank quiz
    does not zero out a whole career.
    """
    careers = fetch_all(
        "SELECT id, title, summary, strengths_text, growth_text, subjects_text FROM career_profiles"
    )
    ranked = []
    for career in careers:
        weights = fetch_all(
            "SELECT trait_key, weight FROM career_profile_weights WHERE career_id = ?",
            (career["id"],),
        )
        if not weights:
            continue
        numerator = 0.0
        denom = 0.0
        reasons = []
        for row in weights:
            trait = row["trait_key"]
            weight = float(row["weight"])
            user_value = float(user_scores.get(trait, 35))
            numerator += user_value * weight
            denom += weight
            if user_value >= 60 and weight >= 0.6:
                reasons.append(TRAIT_LABELS.get(trait, trait))
        match = round(numerator / (denom * 100) * 100, 1) if denom else 0
        ranked.append(
            {
                "id": career["id"],
                "title": career["title"],
                "summary": career["summary"],
                "strengths": career["strengths_text"],
                "growth": career["growth_text"],
                "subjects": career["subjects_text"],
                "match_score": min(99.0, match),
                "why": reasons[:4],
            }
        )
    ranked.sort(key=lambda item: item["match_score"], reverse=True)
    return ranked[:limit]


def describe_hunch(hunch, top_titles):
    """Compare the student's original hunch with the engine's top titles."""
    if not hunch or not hunch.strip():
        return "You did not save a hunch, so these results are a fresh map rather than a comparison."
    if not top_titles:
        return (
            f"Your hunch (“{hunch.strip()}”) is saved. "
            "Finish all three chapters to see how it sits next to recommended paths."
        )
    needle = hunch.strip().lower()
    for title in top_titles:
        if needle in title.lower() or title.lower() in needle:
            return (
                f"Your hunch (“{hunch.strip()}”) sits close to {title}. "
                "The quizzes support that direction and also show neighbouring paths."
            )
    keywords = {
        "software": "Software Developer",
        "coding": "Software Developer",
        "programmer": "Software Developer",
        "developer": "Software Developer",
        "data": "Data Analyst",
        "design": "UX/UI Designer",
        "ui": "UX/UI Designer",
        "ux": "UX/UI Designer",
        "doctor": "Doctor / Healthcare Professional",
        "medicine": "Doctor / Healthcare Professional",
        "teacher": "Teacher / Counselor",
        "lawyer": "Lawyer",
        "business": "Entrepreneur",
        "startup": "Entrepreneur",
        "environment": "Environmental Scientist",
        "scientist": "Research Scientist",
        "research": "Research Scientist",
        "marketing": "Digital Marketer",
        "graphic": "Graphic Designer",
        "ias": "Civil Services / Public Policy Professional",
        "civil": "Civil Services / Public Policy Professional",
        "policy": "Civil Services / Public Policy Professional",
    }
    for word, title in keywords.items():
        if word in needle and title in top_titles:
            return (
                f"Your hunch (“{hunch.strip()}”) is in conversation with {title}, "
                "which also appears in your top matches."
            )
        if word in needle:
            return (
                f"Your hunch (“{hunch.strip()}”) is a real direction to keep. "
                f"The quizzes currently lean toward {top_titles[0]}, which may expand rather than replace that idea."
            )
    return (
        f"Your hunch (“{hunch.strip()}”) is still yours to hold. "
        f"The strongest pattern in these answers currently points toward {top_titles[0]} "
        "— treat that as an invitation to explore, not a verdict."
    )


def top_strengths(user_scores, count=4):
    ranked = sorted(user_scores.items(), key=lambda item: item[1], reverse=True)
    return [
        {"key": key, "label": TRAIT_LABELS.get(key, key), "score": score}
        for key, score in ranked[:count]
    ]


def growth_areas(user_scores, count=3):
    ranked = sorted(user_scores.items(), key=lambda item: item[1])
    return [
        {"key": key, "label": TRAIT_LABELS.get(key, key), "score": score}
        for key, score in ranked[:count]
    ]


def radar_payload(user_scores):
    values = [round(float(user_scores.get(key, 35)), 1) for key in RADAR_KEYS]
    return {"labels": RADAR_CHART_LABELS, "values": values}


def skill_bars(user_scores):
    keys = [
        "analytical",
        "communication",
        "technical",
        "leadership",
        "creativity",
        "problem_solving",
        "attention_to_detail",
    ]
    return [
        {"label": TRAIT_LABELS[key], "score": round(float(user_scores.get(key, 0)), 1)}
        for key in keys
    ]


def interest_slices(user_scores):
    keys = [
        "technology",
        "science",
        "business",
        "arts",
        "social",
        "healthcare",
        "law",
        "environment",
    ]
    return [
        {"label": TRAIT_LABELS[key], "score": round(float(user_scores.get(key, 0)), 1)}
        for key in keys
    ]


ROADMAPS = {
    "Software Developer": {
        "now": "Write small programs every week. Finish one tiny project you can show (a quiz, a calculator, a notes page).",
        "short": "Learn Python or JavaScript properly. Publish two projects on GitHub. Try a beginner hackathon or coding club.",
        "long": "Choose CS / IT or a related degree, or a strong diploma plus internships. Build a portfolio of 4–6 real projects.",
        "skills": "Python or JavaScript, Git, problem-solving, reading documentation.",
        "projects": "Personal website, simple game, data cleaner, school club tool.",
        "portfolio": "GitHub profile, short write-up of each project, one live demo.",
    },
    "Data Analyst": {
        "now": "Practise spreadsheets: sort, filter, pivot, and make one honest chart from school or public data.",
        "short": "Learn basic statistics and beginner SQL. Complete one mini dashboard.",
        "long": "Statistics, economics, or CS at college. Intern where reports are actually used.",
        "skills": "Excel / Google Sheets, charts, SQL, clear writing.",
        "projects": "Analyse a public dataset (sports, weather, exam results) and present three findings.",
        "portfolio": "Two dashboards plus a one-page insight memo.",
    },
    "UX/UI Designer": {
        "now": "Redesign one everyday app screen on paper. Ask two people what confused them.",
        "short": "Learn Figma. Build a 5-screen flow for a school problem. Read about accessibility.",
        "long": "Design, CS, or a mix. Intern with a product team. Keep a case-study habit.",
        "skills": "Figma, user interviews, visual hierarchy, simple prototyping.",
        "projects": "A redesigned school notice board app; a poster series with a grid system.",
        "portfolio": "3 case studies: problem, sketches, final screens, what you changed after feedback.",
    },
    "Doctor / Healthcare Professional": {
        "now": "Protect Biology and Chemistry. Volunteer in a setting where care is real, not just theory.",
        "short": "NEET / equivalent preparation with a sustainable timetable. First-aid certification if available.",
        "long": "MBBS or allied health pathways (nursing, physiotherapy, public health) depending on scores and interest.",
        "skills": "Science depth, empathy, stamina, ethical judgement.",
        "projects": "A simple public-health poster for your school; shadowing notes (with permission).",
        "portfolio": "Academic record, volunteer hours, a reflection on one care experience.",
    },
    "Teacher / Counselor": {
        "now": "Help a classmate understand one topic you already know. Notice how you explain.",
        "short": "Assist in a club, tuition group, or peer-support circle. Read one book on how people learn.",
        "long": "Subject degree plus B.Ed, or psychology / social work for counselling pathways.",
        "skills": "Explanation, listening, lesson structure, patience.",
        "projects": "A 20-minute mini-lesson; a peer-support resource sheet.",
        "portfolio": "Lesson plans, student feedback (anonymous), volunteer record.",
    },
    "Lawyer": {
        "now": "Read one well-written news analysis a day. Practise summarising both sides of a disagreement.",
        "short": "Join debate or moot. Write short arguments with evidence. Explore CLAT / related exams if relevant.",
        "long": "Law degree (5-year integrated or 3-year after graduation) and internships with chambers or NGOs.",
        "skills": "Reading, writing, oral argument, ethics.",
        "projects": "A one-page brief on a public issue; a school debate case file.",
        "portfolio": "Writing samples, debate record, internship notes.",
    },
    "Entrepreneur": {
        "now": "Solve a tiny real problem for someone and charge (or trade) for it. Keep a simple cash note.",
        "short": "Join a start-up club. Interview 10 people about a problem. Build a smallest possible offer.",
        "long": "Any strong degree plus internships. Company registration and accounts when you are actually selling.",
        "skills": "Listening to users, basic finance, selling, finishing.",
        "projects": "A stall, a service for neighbours, a digital product with five paying users.",
        "portfolio": "Problem → offer → what you learned. Honest numbers.",
    },
    "Environmental Scientist": {
        "now": "Pick one local place (lake, park, street trees) and observe it weekly. Write what changes.",
        "short": "Geography / biology projects with real measurements. Join a local conservation group.",
        "long": "Environmental science, ecology, or geography at university. Field internships.",
        "skills": "Field notes, basic data, biology/geography, science communication.",
        "projects": "A biodiversity log; a waste-audit of your school wing.",
        "portfolio": "Field notebook photos, one poster, one short report.",
    },
    "Research Scientist": {
        "now": "Pick a 'why' question and try to answer it with a small, honest experiment or proof.",
        "short": "Science fairs, olympiad practice if it fits, lab club. Learn to write a methods paragraph.",
        "long": "A science or engineering degree, then research internships and possibly postgraduate study.",
        "skills": "Experimental design, maths, patience, scientific writing.",
        "projects": "A controlled experiment; a literature summary of 5 papers or articles.",
        "portfolio": "Lab records, a fair project, a teacher recommendation.",
    },
    "Digital Marketer": {
        "now": "Run a tiny campaign for a school event. Measure what people actually did, not just likes.",
        "short": "Learn basic analytics and copywriting. Build a content calendar and stick to it for a month.",
        "long": "Marketing, communications, or business at college plus internships with real campaigns.",
        "skills": "Writing, visuals, analytics, audience research.",
        "projects": "Event campaign, a newsletter, a short video series.",
        "portfolio": "Before/after metrics and the creative work itself.",
    },
    "Graphic Designer": {
        "now": "Redraw a school poster with a real grid, two fonts, and limited colour.",
        "short": "Daily composition practice. Learn Figma or a professional layout tool. Take one real brief.",
        "long": "Design school or a related degree. Intern at a studio. Keep a dated archive of work.",
        "skills": "Typography, layout, colour, briefing.",
        "projects": "Poster series, a logo with process pages, a zine.",
        "portfolio": "8–12 strong pieces with process, not 40 weak ones.",
    },
    "Civil Services / Public Policy Professional": {
        "now": "Read a quality newspaper with a notebook. Practise explaining one policy in plain language.",
        "short": "Quiz yourself on polity, geography, and economy. Volunteer in a civic project.",
        "long": "Any graduation stream plus serious UPSC / state-service prep, or a public-policy master's later.",
        "skills": "Wide reading, writing, ethics, stamina.",
        "projects": "A local-issue briefing note; a community survey of 20 people.",
        "portfolio": "Essays, current-affairs notes, volunteer record.",
    },
}


def roadmap_for(title):
    return ROADMAPS.get(
        title,
        {
            "now": "Talk to one person who does this work. Write down what a normal Tuesday looks like.",
            "short": "Pick one skill to practise weekly and one subject to protect in school.",
            "long": "Choose a course that keeps this door open, plus internships that test the fit.",
            "skills": "Curiosity, communication, and one craft you can show.",
            "projects": "A small public piece of work related to this field.",
            "portfolio": "Evidence of making, helping, or explaining — not only marks.",
        },
    )


def nearby_jobs(city, career_titles, limit=8):
    """Return sample opportunities filtered by city and top careers."""
    if not career_titles:
        return []
    placeholders = ",".join("?" for _ in career_titles)
    city_value = (city or "Bengaluru").strip()
    rows = fetch_all(
        f"""
        SELECT * FROM job_opportunities
        WHERE career_field IN ({placeholders})
          AND (LOWER(city) = LOWER(?) OR LOWER(city) = 'remote')
        ORDER BY CASE WHEN LOWER(city) = LOWER(?) THEN 0 ELSE 1 END, title
        LIMIT ?
        """,
        (*career_titles, city_value, city_value, limit),
    )
    if len(rows) < 3:
        extra = fetch_all(
            f"""
            SELECT * FROM job_opportunities
            WHERE career_field IN ({placeholders})
            ORDER BY title LIMIT ?
            """,
            (*career_titles, limit),
        )
        seen = {row["id"] for row in rows}
        for row in extra:
            if row["id"] not in seen:
                rows.append(row)
            if len(rows) >= limit:
                break
    return rows


def build_full_report(user):
    """Assemble everything the results page and PDF need."""
    merged, by_slug, completed = latest_completed_scores(user["id"])
    matches = match_careers(merged, limit=5) if merged else []
    titles = [item["title"] for item in matches]
    for item in matches:
        item["roadmap"] = roadmap_for(item["title"])
    hunch_note = describe_hunch(user.get("career_hunch") or "", titles)
    jobs = nearby_jobs(user.get("city") or "Bengaluru", titles)
    payload = {
        "scores": merged,
        "by_slug": by_slug,
        "completed": completed,
        "complete": set(completed) >= {"personality", "skills", "interests"},
        "matches": matches,
        "hunch_note": hunch_note,
        "strengths": top_strengths(merged),
        "growth": growth_areas(merged),
        "radar": radar_payload(merged),
        "skill_bars": skill_bars(merged),
        "interest_slices": interest_slices(merged),
        "jobs": jobs,
    }
    if payload["complete"] and matches:
        execute(
            """
            INSERT INTO combined_results
                (user_id, hunch, scores_json, matches_json, strengths_json, growth_json)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                user["id"],
                user.get("career_hunch") or "",
                json.dumps(merged),
                json.dumps(matches),
                json.dumps(payload["strengths"]),
                json.dumps(payload["growth"]),
            ),
        )
        payload["result_id"] = fetch_one(
            "SELECT id FROM combined_results WHERE user_id = ? ORDER BY id DESC LIMIT 1",
            (user["id"],),
        )["id"]
    return payload


def profile_summary(user, report):
    name = user.get("full_name") or user.get("username")
    if not report["complete"]:
        missing = [item for item in ("personality", "skills", "interests") if item not in report["completed"]]
        pretty = ", ".join(item.title() for item in missing)
        return (
            f"{name}, you have started mapping a direction. "
            f"Finish {pretty} to unlock the full career match view."
        )
    top = report["matches"][0]["title"] if report["matches"] else "several neighbouring fields"
    return (
        f"{name}, your answers currently form a profile that fits {top} especially well. "
        "Read this as a well-lit map, not a fixed destiny."
    )
