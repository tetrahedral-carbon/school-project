"""
Basic automated tests for Career Compass.

Run from the project root:
    python3 -m unittest tests.test_app -v
"""

import os
import tempfile
import unittest

# Use a throwaway SQLite file so tests never touch a teacher's real database.
_fd, _DB = tempfile.mkstemp(suffix=".db")
os.close(_fd)
os.environ["SQLITE_PATH"] = _DB
os.environ["MYSQL_HOST"] = ""
os.environ["SECRET_KEY"] = "test-secret"
os.environ["FLASK_DEBUG"] = "0"

from werkzeug.security import check_password_hash  # noqa: E402

from app import app  # noqa: E402
from database import fetch_all, fetch_one, execute  # noqa: E402
from seed_data import ADMIN_PASSWORD_HASH  # noqa: E402


class CareerCompassTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        app.config["TESTING"] = True
        cls.client = app.test_client()

    def csrf(self):
        with self.client.session_transaction() as sess:
            return sess["csrf_token"]

    def test_01_home_renders(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Career Compass", response.data)
        self.assertIn(b"Admin access", response.data)

    def test_02_admin_hash_matches_demo_password(self):
        self.assertTrue(check_password_hash(ADMIN_PASSWORD_HASH, "Admin123"))
        row = fetch_one("SELECT password_hash FROM admins WHERE username = ?", ("Admin",))
        self.assertIsNotNone(row)
        self.assertTrue(check_password_hash(row["password_hash"], "Admin123"))

    def test_03_register_validation(self):
        self.client.get("/register")
        token = self.csrf()
        bad = self.client.post(
            "/register",
            data={
                "csrf_token": token,
                "full_name": "A",
                "username": "ab",
                "password": "short",
                "confirm": "short",
                "city": "Bengaluru",
                "career_hunch": "Doctor",
            },
        )
        self.assertEqual(bad.status_code, 400)

    def test_04_register_login_and_hunch(self):
        self.client.get("/register")
        token = self.csrf()
        created = self.client.post(
            "/register",
            data={
                "csrf_token": token,
                "full_name": "Test Student",
                "username": "test_student",
                "password": "Secret123",
                "confirm": "Secret123",
                "city": "Bengaluru",
                "career_hunch": "Software Developer",
            },
            follow_redirects=True,
        )
        self.assertEqual(created.status_code, 200)
        self.assertIn(b"My Path", created.data)
        self.assertIn(b"Software Developer", created.data)
        user = fetch_one("SELECT * FROM users WHERE username = ?", ("test_student",))
        self.assertIsNotNone(user)
        self.assertNotEqual(user["password_hash"], "Secret123")
        self.assertIn("pbkdf2", user["password_hash"])

    def test_05_unique_username(self):
        self.client.get("/logout", follow_redirects=True)
        self.client.get("/register")
        token = self.csrf()
        again = self.client.post(
            "/register",
            data={
                "csrf_token": token,
                "full_name": "Copy Cat",
                "username": "test_student",
                "password": "Secret123",
                "confirm": "Secret123",
                "city": "Bengaluru",
                "career_hunch": "Lawyer",
            },
        )
        self.assertEqual(again.status_code, 400)

    def test_06_login_and_resume_storage(self):
        self.client.get("/logout", follow_redirects=True)
        self.client.get("/login")
        token = self.csrf()
        logged = self.client.post(
            "/login",
            data={"csrf_token": token, "username": "test_student", "password": "Secret123"},
            follow_redirects=True,
        )
        self.assertEqual(logged.status_code, 200)
        start = self.client.get("/quiz/personality/start", follow_redirects=True)
        self.assertEqual(start.status_code, 200)
        question_page = self.client.get("/quiz/personality/question/1")
        self.assertEqual(question_page.status_code, 200)
        option = fetch_one(
            """
            SELECT qo.id, q.id AS question_id FROM question_options qo
            JOIN quiz_questions q ON q.id = qo.question_id
            JOIN quiz_categories c ON c.id = q.category_id
            WHERE c.slug = 'personality' AND q.is_active = 1
            ORDER BY q.display_order, qo.display_order LIMIT 1
            """
        )
        token = self.csrf()
        saved = self.client.post(
            "/quiz/personality/save-answer",
            data={
                "csrf_token": token,
                "option_id": option["id"],
                "question_id": option["question_id"],
            },
        )
        self.assertEqual(saved.status_code, 200)
        self.client.get("/logout", follow_redirects=True)
        self.client.get("/login")
        token = self.csrf()
        self.client.post(
            "/login",
            data={"csrf_token": token, "username": "test_student", "password": "Secret123"},
            follow_redirects=True,
        )
        resume = self.client.get("/quiz/personality/resume", follow_redirects=True)
        self.assertEqual(resume.status_code, 200)
        answers = fetch_all("SELECT * FROM user_answers")
        self.assertGreaterEqual(len(answers), 1)

    def test_07_incomplete_results_page(self):
        page = self.client.get("/results")
        self.assertEqual(page.status_code, 200)
        self.assertIn(b"chapters are still open", page.data)
        pdf = self.client.get("/download-report", follow_redirects=True)
        self.assertEqual(pdf.status_code, 200)
        self.assertNotEqual(pdf.mimetype, "application/pdf")

    def test_08_admin_login_and_add_question(self):
        self.client.get("/logout", follow_redirects=True)
        self.client.get("/admin/logout", follow_redirects=True)
        self.client.get("/admin/login")
        token = self.csrf()
        denied = self.client.get("/admin/questions", follow_redirects=True)
        self.assertIn(b"Admin", denied.data)
        ok = self.client.post(
            "/admin/login",
            data={"csrf_token": token, "username": "Admin", "password": "Admin123"},
            follow_redirects=True,
        )
        self.assertEqual(ok.status_code, 200)
        self.assertIn(b"Question workshop", ok.data)
        self.assertIn(b"Students", ok.data)
        category = fetch_one("SELECT id FROM quiz_categories WHERE slug = 'skills'")
        token = self.csrf()
        added = self.client.post(
            "/admin/questions/add",
            data={
                "csrf_token": token,
                "category_id": category["id"],
                "question_text": "I can keep a lab notebook tidy and complete.",
                "question_type": "likert",
                "dimension": "attention_to_detail",
                "image_icon": "book",
                "is_active": "1",
                "display_order": "99",
                "option_text[]": [
                    "Not like me yet",
                    "Rarely like me",
                    "Sometimes like me",
                    "Often like me",
                    "Very much like me",
                ],
                "option_emoji[]": ["1", "2", "3", "4", "5"],
                "option_score[]": ["1", "2", "3", "4", "5"],
                "option_dimension[]": [
                    "attention_to_detail",
                    "attention_to_detail",
                    "attention_to_detail",
                    "attention_to_detail",
                    "attention_to_detail",
                ],
            },
            follow_redirects=True,
        )
        self.assertEqual(added.status_code, 200)
        row = fetch_one(
            "SELECT * FROM quiz_questions WHERE question_text LIKE ?",
            ("%lab notebook%",),
        )
        self.assertIsNotNone(row)
        self.client.get("/admin/logout")

    def test_09_seeded_question_counts(self):
        for slug in ("personality", "skills", "interests"):
            rows = fetch_all(
                """
                SELECT q.id FROM quiz_questions q
                JOIN quiz_categories c ON c.id = q.category_id
                WHERE c.slug = ? AND q.is_active = 1
                """,
                (slug,),
            )
            self.assertGreaterEqual(len(rows), 10, slug)

    def test_10_student_cannot_open_admin(self):
        self.client.get("/login")
        token = self.csrf()
        self.client.post(
            "/login",
            data={"csrf_token": token, "username": "test_student", "password": "Secret123"},
            follow_redirects=True,
        )
        page = self.client.get("/admin/dashboard", follow_redirects=True)
        self.assertIn(b"Admin username", page.data)
        self.assertNotIn(b"Recent admin actions", page.data)


if __name__ == "__main__":
    unittest.main()
