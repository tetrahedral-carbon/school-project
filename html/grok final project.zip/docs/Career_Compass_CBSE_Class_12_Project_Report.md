# Career Compass
## CBSE Class 12 Computer Science Project Report

**Tagline:** Discover your direction. Design your future.

| Field | Details |
| --- | --- |
| Student Name | [Student Name] |
| Class / Section | [Class/Section] |
| Roll Number | [Roll Number] |
| School Name | [School Name] |
| Teacher Name | [Teacher Name] |
| Academic Session | [Academic Session] |
| Subject | Computer Science (083) |
| Language / Tools | Python, Flask, MySQL, HTML, CSS, JavaScript |

---

## 1. Cover Page

**CAREER COMPASS**  
An Interactive Career Guidance Web Application  

A project report submitted in partial fulfilment of the requirements for  
Class XII Computer Science  
Session [Academic Session]  

Submitted by: **[Student Name]**  
Guided by: **[Teacher Name]**  
[School Name]

---

## 2. Certificate

This is to certify that **[Student Name]**, Roll No. **[Roll Number]**, of Class **[Class/Section]**, [School Name], has completed the project titled **“Career Compass — Discover your direction. Design your future.”** under my guidance during the academic session **[Academic Session]**. The work is original to the best of my knowledge and is suitable for submission to the Central Board of Secondary Education.

Teacher’s signature: ____________________  
Date: ____________________  
School stamp:

---

## 3. Student Declaration

I, **[Student Name]**, hereby declare that the project **Career Compass** is my own work. It has been completed under the supervision of **[Teacher Name]**. The source code, database design, and documentation have not been copied from any other student. Wherever external libraries (Flask, ReportLab, Chart.js) are used, they are acknowledged.

Signature of student: ____________________  
Date: ____________________

---

## 4. Acknowledgement

I thank **[Teacher Name]** for patient guidance, **[School Name]** for laboratory facilities, and my family for time and encouragement. I also acknowledge the open-source communities behind Python, Flask, MySQL, and Chart.js, which made a complete web application possible at school level.

---

## 5. Abstract / Synopsis

Career Compass is a web-based career exploration tool for senior-secondary students. After creating a secure account, a learner records a career “hunch” and completes three quizzes — Personality, Skills, and Interests. Answers are stored in MySQL (or SQLite when MySQL is unavailable). A transparent scoring module converts answers into trait scores and recommends three to five career paths, each with a match score, explanation, roadmap, and sample nearby opportunities. Results can be downloaded as a PDF. An admin console lets a teacher edit the question bank without changing Python code.

The project demonstrates Python–MySQL connectivity, password hashing, session handling, CRUD operations, and front-end visualisation.

---

## 6. Table of Contents

1. Cover Page  
2. Certificate  
3. Student Declaration  
4. Acknowledgement  
5. Abstract  
6. Table of Contents  
7. Introduction  
8. Problem Statement  
9. Objectives  
10. Scope  
11. Existing System and Limitations  
12. Proposed System  
13. Hardware Requirements  
14. Software Requirements  
15. Tools and Technologies  
16. System Design and Architecture  
17. Data Flow  
18. Flowchart description  
19. Database Design  
20. ER Diagram  
21. Table Structure and Data Dictionary  
22. Module Descriptions  
23. Important Algorithms  
24. Key Source-Code Explanations  
25. Testing Plan  
26. Sample Output Screens  
27. Security and Privacy  
28. Limitations  
29. Future Scope  
30. Conclusion  
31. Bibliography  
32. Appendix  
33. Viva Voce Questions  

---

## 7. Introduction

Choosing a stream or a career in Class 11–12 is often based on marks, family pressure, or a single conversation. Students rarely get a quiet, structured way to notice how they work with people, what they can already do, and what genuinely holds their attention.

Career Compass is a small, original website that treats career thinking as a map, not a verdict. It is educational software. It is **not** a psychological test, a medical tool, or a guarantee of any college or job outcome.

---

## 8. Problem Statement

School computer-science projects often stop at a login form and a few quizzes that vanish when the browser closes. Students and examiners both need:

- permanent storage of accounts and answers in a real database;
- passwords that are not stored as plain text;
- a quiz that can be paused and resumed;
- results that can be explained, not a mysterious “AI score”;
- a report that can be printed or submitted.

Career Compass is designed to meet those needs in one runnable project.

---

## 9. Objectives

1. Design a relational database for users, questions, answers, and careers.  
2. Implement secure registration and login using hashed passwords and sessions.  
3. Provide three independent quizzes with auto-save and resume.  
4. Compute career matches with a documented local algorithm.  
5. Display charts and a downloadable PDF.  
6. Allow an administrator to maintain the question bank.  
7. Keep the code simple enough for a Class 12 student to explain.

---

## 10. Scope of the Project

**In scope:** student registration, three quizzes, scoring, results, sample jobs, PDF, admin CRUD for questions.

**Out of scope:** live job APIs, payment, school MIS integration, professional psychometric validation, mobile native apps.

---

## 11. Existing System and Its Limitations

| Existing approach | Limitation |
| --- | --- |
| One-off paper quizzes | Results are not stored; hard to compare later |
| Random internet quizzes | Unknown scoring; ads; privacy risk |
| Spreadsheet trackers | No login, no admin question bank, no PDF |
| Commercial apps | Cost, closed source, hard to submit as a school project |

---

## 12. Proposed System

A Flask website with Jinja2 templates. MySQL holds permanent records. The first launch can also use SQLite so a demo still runs on a lab PC without MySQL. The recommendation engine lives in `scoring.py` and can be read line by line.

---

## 13. Hardware Requirements

- A standard PC or laptop (4 GB RAM or more recommended)
- Keyboard, mouse, and display
- Optional: printer for the project report and PDF output

---

## 14. Software Requirements

- Python 3.10+
- Flask, Werkzeug, ReportLab, mysql-connector-python
- MySQL 8+ (optional if SQLite is used)
- Chrome, Firefox, or Edge
- A text editor such as VS Code or IDLE

---

## 15. Tools and Technologies Used

| Layer | Choice | Why |
| --- | --- | --- |
| Language | Python 3 | CBSE prescribed language |
| Web framework | Flask | Small, explicit routes |
| Templates | Jinja2 | HTML with server data |
| Database | MySQL 8 / SQLite | Relational, examined in Class 12 |
| Connector | mysql-connector-python + sqlite3 | Parameterised queries |
| Passwords | Werkzeug `generate_password_hash` | pbkdf2, no plain text |
| Charts | Chart.js | Radar, bar, doughnut |
| PDF | ReportLab | Pure Python, no extra OS libraries |
| Front end | HTML5, CSS3, JavaScript | Independent of React/Node |

---

## 16. System Design and Architecture

```
Browser (HTML/CSS/JS)
        |
        v
Flask routes in app.py  (sessions, CSRF token, validation)
        |
        +--> database.py  (parameterised SQL)
        |         |
        |         v
        |    MySQL or SQLite
        |
        +--> scoring.py   (trait averages + weighted career match)
        |
        +--> pdf_service.py (ReportLab)
```

Two roles exist: **student** (`users` table) and **admin** (`admins` table). Decorators `login_required` and `admin_required` block the wrong role.

---

## 17. Data Flow / Working Process

1. Visitor opens `/` and either signs in or registers.  
2. Registration stores username, hash, name, city, and hunch.  
3. Dashboard shows three chapters and their status.  
4. Starting a quiz inserts `quiz_attempts`.  
5. Each answer upserts `user_answers`.  
6. Submit writes `quiz_results` and marks the attempt completed.  
7. `/results` merges the latest completed chapter of each type, ranks careers, and lists sample jobs for the student’s city.  
8. `/download-report` builds a PDF in memory.

---

## 18. Flowchart description

**Login:** Start → enter username/password → valid? No → error. Yes → session → dashboard.

**Quiz:** Start/resume attempt → show question n → save option → last question? No → n+1. Yes → review unanswered → complete.

**Admin:** Admin login → list questions → add/edit/delete → audit log → student quiz reads same rows.

---

## 19. Database Design

The schema is in Third Normal Form as far as a school project reasonably goes:

- User details are not repeated inside answers.
- Options belong to questions; questions belong to categories.
- Attempts belong to a user and a category; answers belong to an attempt.
- Career weights are a separate table so a career can have many traits.

Foreign keys and indexes are declared in `database/schema.sql`.

---

## 20. ER Diagram description

```mermaid
erDiagram
  USERS ||--o{ QUIZ_ATTEMPTS : starts
  USERS ||--o{ COMBINED_RESULTS : receives
  ADMINS ||--o{ ADMIN_AUDIT_LOGS : writes
  QUIZ_CATEGORIES ||--o{ QUIZ_QUESTIONS : contains
  QUIZ_QUESTIONS ||--o{ QUESTION_OPTIONS : has
  QUIZ_ATTEMPTS ||--o{ USER_ANSWERS : records
  QUIZ_QUESTIONS ||--o{ USER_ANSWERS : answered
  CAREER_PROFILES ||--o{ CAREER_PROFILE_WEIGHTS : weighted_by
  USERS ||--o{ USER_REFLECTIONS : notes
```

ASCII sketch:

```
USERS 1---* QUIZ_ATTEMPTS 1---* USER_ANSWERS *---1 QUIZ_QUESTIONS
ADMINS 1---* ADMIN_AUDIT_LOGS
QUIZ_CATEGORIES 1---* QUIZ_QUESTIONS 1---* QUESTION_OPTIONS
CAREER_PROFILES 1---* CAREER_PROFILE_WEIGHTS
```

---

## 21. Table Structure and Data Dictionary

| Table | Purpose | Key fields |
| --- | --- | --- |
| users | Student accounts | id, username UNIQUE, password_hash, city, career_hunch |
| admins | Staff accounts | id, username, password_hash |
| quiz_categories | Three chapters | slug, name |
| quiz_questions | Question bank | category_id, question_type, dimension, is_active |
| question_options | Choices and scores | question_id, score_value, dimension |
| quiz_attempts | Pause/resume/complete | user_id, status, current_index |
| user_answers | Saved answers | attempt_id + question_id UNIQUE |
| quiz_results | Chapter snapshots | scores_json |
| career_profiles | Recommendable careers | title, summary |
| career_profile_weights | Trait weights | career_id, trait_key, weight |
| job_opportunities | Sample listings | city, career_field, is_sample |
| combined_results | Full report snapshot | matches_json |
| user_reflections | Results-page notes | note |
| admin_audit_logs | Admin history | action, details |

Normalisation note: repeating a student’s name inside every answer would violate 2NF/3NF. We store `user_id` instead.

---

## 22. Module Descriptions

| File | Role |
| --- | --- |
| `app.py` | Routes, validation, decorators |
| `config.py` | Environment variables |
| `database.py` | Connect, query, create SQLite tables |
| `seed_data.py` | Questions, careers, jobs, admin hash |
| `scoring.py` | Averages, match scores, roadmaps |
| `pdf_service.py` | PDF layout |
| `templates/` | Jinja2 pages |
| `static/` | CSS, JS, SVG |

---

## 23. Important Algorithms / Pseudocode

**Password hashing**

```
hash ← generate_password_hash(password, method="pbkdf2:sha256:260000")
store hash
on login: check_password_hash(stored_hash, typed_password)
```

**Trait score**

```
for each answer in a chapter:
    bucket[dimension].append(score_value)   # 1 to 5
trait_score[dimension] ← average(bucket) / 5 * 100
```

**Career match**

```
for each career:
    numerator ← Σ user[trait] * weight[trait]
    denom ← Σ weight[trait]
    match ← numerator / (denom * 100) * 100
sort careers by match descending
take top 5
```

Missing traits use a gentle middle value (35) so one unfinished quiz does not zero a career. This is documented on the results page as educational, not clinical.

---

## 24. Key Source-Code Explanations

**Python–MySQL connectivity.** `database.connect()` opens MySQL when `MYSQL_HOST` is set, otherwise SQLite. `fetch_all` / `execute` replace `?` with `%s` for MySQL. User input is always passed as parameters, never concatenated into SQL.

**Why hashing matters.** If a database file is copied, an attacker should not read everyone’s password. Hashing (pbkdf2) is one-way. Even the developer cannot recover `Admin123` from the hash without guessing.

**Sessions.** After login, Flask stores `user_id` in a signed cookie marked HttpOnly. Pages such as `/dashboard` call `login_required`.

**Auto-save.** `quiz.js` posts the chosen option to `/quiz/<type>/save-answer`. The server upserts `user_answers`.

---

## 25. Testing Plan and Test Cases

Automated tests live in `tests/test_app.py`.

| ID | Case | Expected |
| --- | --- | --- |
| T1 | Open `/` | Landing page with Career Compass and Admin access |
| T2 | Register invalid username | HTTP 400, friendly error |
| T3 | Register valid student | Row in `users`, redirect to dashboard, hunch visible |
| T4 | Duplicate username | Rejected |
| T5 | Login after logout | Dashboard |
| T6 | Save answer, logout, resume | Same answer still present |
| T7 | Results before 3 quizzes | Incomplete message, no PDF |
| T8 | Admin hash | `Admin123` verifies against seeded hash |
| T9 | Admin add question | New row; student quiz can load it |
| T10 | Student opens `/admin/dashboard` | Redirected to admin login |

---

## 26. Sample Output Screens / screenshot placeholders

Insert prints after the practical run:

1. Landing / sign-in  
2. Registration with hunch  
3. My Path dashboard  
4. Personality question with option cards  
5. Review screen  
6. Results constellation and radar chart  
7. Sample opportunity cards  
8. Admin question table  
9. First page of the PDF  

---

## 27. Security and Privacy Considerations

- Passwords hashed with pbkdf2; never logged.  
- HttpOnly session cookie; CSRF token on POST forms.  
- Parameterised SQL.  
- Login attempt window (rate limit).  
- Admin credentials stored hashed; demo pair must be changed in production.  
- Sample jobs are labelled so the site does not invent live vacancies.  
- Disclaimer on results and PDF: educational exploration only.

---

## 28. Limitations

- The quizzes are not standardised psychometric instruments.  
- Sample jobs are not live.  
- The engine is rules-based; it does not call a paid AI API.  
- One lab PC, one SQLite file is enough for a demo but not for a whole school without MySQL and a proper secret key.  
- Forgot-password is a visual demo only.

---

## 29. Future Scope

- Connect a legitimate jobs API when a key is available.  
- Optional teacher accounts per school.  
- Multilingual interface (Hindi / regional language).  
- Export anonymised class-level charts for a counsellor.  
- Two-factor authentication for admin.

---

## 30. Conclusion

Career Compass shows that a Class 12 student can build a complete web application: accounts, a real database, pause/resume quizzes, a scoring model that can be explained on the blackboard, charts, and a PDF. The project’s most important sentence remains on every results page: this is a map for exploration, not a diagnosis and not a destiny.

---

## 31. Bibliography

1. CBSE, *Computer Science Class XII* curriculum (083).  
2. Flask documentation, https://flask.palletsprojects.com/  
3. Werkzeug security utilities, https://werkzeug.palletsprojects.com/  
4. MySQL 8.0 Reference Manual.  
5. ReportLab User Guide.  
6. Chart.js documentation.  
7. Python Software Foundation, *Python 3 Language Reference*.

---

## 32. Appendix

### Installation (short)

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 app.py
```

### Important SQL

```sql
CREATE DATABASE career_compass_db CHARACTER SET utf8mb4;
-- then import database/schema.sql and database/sample_data.sql
```

### Important snippet — hashing

```python
from werkzeug.security import generate_password_hash, check_password_hash
stored = generate_password_hash(password, method="pbkdf2:sha256:260000")
check_password_hash(stored, password)
```

### Important snippet — parameterised query

```python
user = fetch_one("SELECT * FROM users WHERE username = ?", (username,))
```

---

## 33. Viva Voce Questions and Answers

1. **What is Flask?** A lightweight Python web framework that maps URLs to Python functions.  
2. **Why MySQL?** It is a relational database taught in Class 12 and stores permanent records with keys and constraints.  
3. **What is SQLite doing in this project?** If MySQL is not installed, the same tables are created in a local file so the demo still runs.  
4. **What is a primary key?** A unique identifier for a row, for example `users.id`.  
5. **What is a foreign key?** A field that points to a primary key in another table, for example `quiz_attempts.user_id`.  
6. **What is normalisation?** Organising tables so each fact is stored once. We do not copy the student’s name into every answer.  
7. **Why hash passwords?** So a stolen database does not reveal the original password. Hashing is one-way.  
8. **What is pbkdf2?** A slow hashing method that includes a salt, making guessing expensive.  
9. **What is a session?** Server-side (or signed-cookie) memory of who is logged in, used here with HttpOnly cookies.  
10. **How do you prevent SQL injection?** Always pass user data as parameters, never concatenate it into the SQL string.  
11. **How is a paused quiz resumed?** The latest `quiz_attempts` row with status `paused` or `in_progress` stores `current_index`; answers remain in `user_answers`.  
12. **Why not overwrite old attempts?** A student may want to compare two tries. Inserting a new attempt keeps history.  
13. **How is the match score calculated?** Weighted overlap of the student’s 0–100 trait scores and each career’s weights.  
14. **Is this a psychological test?** No. The disclaimer states it is educational exploration only.  
15. **How does the admin panel affect the quiz?** Both use `quiz_questions`. An insert/update/delete is visible on the next student load.  
16. **What is CSRF protection?** A hidden token that must match the session so another site cannot submit forms as the student.  
17. **How are charts made?** Chart.js reads JSON that the server embedded in the results page.  
18. **How is the PDF built?** ReportLab draws paragraphs and tables in memory; Flask returns them as `application/pdf`.  
19. **What is JSON doing in MySQL?** `scores_json` stores a dictionary of trait scores without extra tables.  
20. **What would you add next?** A real jobs API, multilingual text, and a stronger admin password policy.

---

**End of report**
