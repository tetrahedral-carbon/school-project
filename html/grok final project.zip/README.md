# Career Compass

**Discover your direction. Design your future.**

Career Compass is a student career-guidance website. A learner signs in, answers three separate quizzes (Personality, Skills, Interests), and receives a transparent career map with charts, sample nearby opportunities, learning roadmaps, and a downloadable PDF.

This project is written in Python (Flask) + MySQL, with HTML, CSS, and JavaScript templates. It is intended to be readable, editable, and demonstrable for a CBSE Class 12 computer-science project.

## Features

- Unique usernames and hashed passwords (never stored in plain text)
- Session-based login with protected student and admin routes
- Optional career “hunch” stored in the database
- Three independent quizzes with pause, resume, back, auto-save, and review
- Each quiz attempt is a new record — old results are never overwritten
- Rules-based recommendation engine (no paid AI key required)
- Radar, bar, and doughnut charts on the results page (Chart.js)
- Sample nearby jobs/internships labelled as local database records
- PDF report via ReportLab
- Admin console to add, edit, and delete questions
- SQLite fallback so the app still runs when MySQL is not installed

## Folder structure

```
career-compass/
├── app.py
├── config.py
├── database.py
├── seed_data.py
├── scoring.py
├── pdf_service.py
├── requirements.txt
├── README.md
├── .env.example
├── database/
│   ├── schema.sql
│   └── sample_data.sql
├── static/
│   ├── css/
│   ├── js/
│   └── images/
├── templates/
├── docs/
│   └── Career_Compass_CBSE_Class_12_Project_Report.md
└── tests/
    └── test_app.py
```

## Prerequisites

- Python 3.10 or newer
- pip
- MySQL 8+ **or** nothing extra (SQLite is used automatically)
- A modern browser

Optional for MySQL on a school PC: MySQL Server + MySQL Workbench.

## Python virtual-environment setup

```bash
cd career-compass
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## MySQL setup (optional)

If you want the “full” Class 12 MySQL demonstration:

```bash
mysql -u root -p < database/schema.sql
mysql -u root -p < database/sample_data.sql
```

Copy `.env.example` to `.env` and fill in:

```
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=your_mysql_password
MYSQL_DATABASE=career_compass_db
SECRET_KEY=choose-a-long-random-string
```

The Flask app reads these variables. Leave `MYSQL_HOST` empty to use SQLite (`instance/career_compass.db`). The first launch creates tables and seeds questions automatically.

## How to run Flask

```bash
python3 app.py
```

The site listens on port 8080 by default (`0.0.0.0:8080`).

Default URLs:

- Student sign-in: `/`
- Registration: `/register`
- Workspace: `/dashboard`
- Results: `/results`
- Admin sign-in: `/admin/login`

## Demo student flow

1. Open the landing page.
2. Choose **Create account**.
3. Enter name, username, city (try `Bengaluru`), password, and a career hunch.
4. On **My Path**, start Personality, then Skills, then Interests.
5. Use Back, Pause, and Save & leave — answers store after every question.
6. When all three chapters are complete, open **Results**.
7. Download the PDF report.

## Admin credentials (demonstration only)

- Username: `Admin`
- Password: `Admin123`

Only the hashed password is stored in the database. **Change these before any real deployment.** They exist so a teacher or examiner can open the question workshop during a viva.

A small **Admin access** control sits at the bottom-right of the student sign-in page.

### Editing questions

1. Sign in at `/admin/login`.
2. Open **Manage questions**.
3. Add, edit, or delete items by category.
4. Mark a question inactive to hide it without deleting history.
5. Student quizzes read the same tables, so changes show up immediately.

## Scoring engine (no paid API)

Each answer has a score from 1 to 5 and a trait key (for example `analytical` or `arts`). A chapter score is the average of those answers, scaled to 0–100. Career match scores are a weighted overlap between the student’s trait vector and each career’s stored weights. If an AI API key is not configured, this local engine is the entire recommendation system.

## Jobs / opportunities

Rows in `job_opportunities` are **sample/local database opportunities**. They are never presented as live vacancies. A `JOBS_API_KEY` slot exists in `.env.example` for a future legitimate jobs API.

## Testing

```bash
python3 -m unittest tests.test_app -v
```

### Manual testing checklist

- [ ] Register with a valid username/password; invalid values show friendly errors
- [ ] Duplicate username is rejected
- [ ] Password in the database is hashed
- [ ] Pause a quiz, log out, log in, resume on the same question
- [ ] Back does not lose a previous answer
- [ ] Results page is gentle when quizzes are incomplete
- [ ] Completing all three quizzes shows matches, charts, sample jobs, and PDF
- [ ] Admin can add/edit/delete a question and it appears/disappears in the quiz
- [ ] Non-admin users cannot open `/admin/dashboard`
- [ ] PDF downloads after all quizzes are complete

## Troubleshooting

| Problem | What to try |
| --- | --- |
| `mysql.connector` errors | Leave `MYSQL_HOST` empty to use SQLite, or check MySQL is running |
| Port already in use | Set `FLASK_PORT=5000` in the environment |
| PDF does not download | Finish all three quizzes first; ReportLab must be installed |
| Charts missing | Allow the Chart.js CDN, or check the browser console |
| Admin login fails | Confirm seed ran; hash in `seed_data.py` matches `Admin123` |
| CSS looks unstyled | Confirm `static/css` is next to `app.py` and Flask started from the project root |

## Screenshot placeholders

Replace these with your own captures after running the project:

1. `screenshots/01-landing.png` — animated landing / sign-in
2. `screenshots/02-register.png` — registration with hunch
3. `screenshots/03-dashboard.png` — My Path chapter map
4. `screenshots/04-quiz.png` — one question with option cards
5. `screenshots/05-results.png` — constellation + radar chart
6. `screenshots/06-admin.png` — question workshop
7. `screenshots/07-pdf.png` — first page of the downloaded report

## Architecture (short)

- **Auth.** Werkzeug hashes + Flask sessions in HttpOnly cookies. Decorators protect student and admin routes.
- **Drafts.** `quiz_attempts.status` is `in_progress`, `paused`, or `completed`. `user_answers` upserts after every question.
- **Previous results.** Starting again inserts a new attempt. Scoring reads the latest completed attempt per chapter.
- **Admin.** Separate `admins` table. Audit rows record add/edit/delete.
- **AI / recommendations.** Local weighted engine in `scoring.py`. Optional `AI_API_KEY` is unused unless you extend the project.

## Security notes

Demonstration credentials must be changed for real use. Never commit a filled `.env` file. The app uses parameterised SQL only.
