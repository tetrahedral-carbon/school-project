(function () {
  "use strict";

  var mapping = document.getElementById("mapping-screen");
  var mappingMsg = document.getElementById("mapping-msg");
  if (mapping && mappingMsg) {
    var lines = [
      "Reading the connections between your answers",
      "Looking for environments where you may thrive",
      "Turning patterns into possible directions"
    ];
    var i = 0;
    var timer = setInterval(function () {
      i += 1;
      mappingMsg.textContent = lines[i % lines.length];
      if (i >= 4) {
        clearInterval(timer);
        mapping.classList.add("is-done");
      }
    }, 700);
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      clearInterval(timer);
      mapping.classList.add("is-done");
    }
  }

  if (typeof Chart === "undefined") return;

  var ink = "#1a1f36";
  var teal = "#1aa7a1";
  var coral = "#e85d4c";
  var navy = "#0b1b4a";
  var gold = "#c9a227";

  function readJson(id) {
    var node = document.getElementById(id);
    if (!node) return null;
    try { return JSON.parse(node.textContent); } catch (e) { return null; }
  }

  var radar = readJson("chart-data");
  var skills = readJson("skill-data");
  var interests = readJson("interest-data");

  Chart.defaults.font.family = "Outfit, Segoe UI, sans-serif";
  Chart.defaults.color = ink;

  var radarCanvas = document.getElementById("radarChart");
  if (radarCanvas && radar && radar.labels) {
    new Chart(radarCanvas, {
      type: "radar",
      data: {
        labels: radar.labels,
        datasets: [{
          label: "Your profile",
          data: radar.values,
          borderColor: teal,
          backgroundColor: "rgba(26, 167, 161, 0.18)",
          pointBackgroundColor: navy,
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        scales: {
          r: {
            suggestedMin: 0,
            suggestedMax: 100,
            ticks: { display: false },
            grid: { color: "rgba(26,31,54,0.12)" },
            angleLines: { color: "rgba(26,31,54,0.12)" }
          }
        },
        plugins: { legend: { display: false } }
      }
    });
  }

  var skillCanvas = document.getElementById("skillsChart");
  if (skillCanvas && skills) {
    new Chart(skillCanvas, {
      type: "bar",
      data: {
        labels: skills.map(function (row) { return row.label; }),
        datasets: [{
          label: "Skill score",
          data: skills.map(function (row) { return row.score; }),
          backgroundColor: navy
        }]
      },
      options: {
        indexAxis: "y",
        responsive: true,
        scales: { x: { suggestedMin: 0, suggestedMax: 100 } },
        plugins: { legend: { display: false } }
      }
    });
  }

  var interestCanvas = document.getElementById("interestChart");
  if (interestCanvas && interests) {
    new Chart(interestCanvas, {
      type: "doughnut",
      data: {
        labels: interests.map(function (row) { return row.label; }),
        datasets: [{
          data: interests.map(function (row) { return row.score; }),
          backgroundColor: [teal, coral, navy, gold, "#5c6378", "#0e7f7a", "#16306e", "#d9d3c4"]
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: "bottom", labels: { boxWidth: 12 } } }
      }
    });
  }
})();
