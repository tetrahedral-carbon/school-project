(function () {
  "use strict";

  document.querySelectorAll(".toggle-password").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var id = btn.getAttribute("data-target");
      var input = document.getElementById(id);
      if (!input) return;
      var hidden = input.getAttribute("type") === "password";
      input.setAttribute("type", hidden ? "text" : "password");
      btn.textContent = hidden ? "Hide" : "Show";
      btn.setAttribute("aria-label", hidden ? "Hide password" : "Show password");
    });
  });

  document.querySelectorAll("form[data-validate]").forEach(function (form) {
    form.addEventListener("submit", function (event) {
      var username = form.querySelector('input[name="username"]');
      var password = form.querySelector('input[name="password"]');
      var confirm = form.querySelector('input[name="confirm"]');
      var messages = [];
      if (username && !/^[A-Za-z0-9_]{3,20}$/.test(username.value.trim())) {
        messages.push("Username must be 3–20 letters, numbers, or underscores.");
      }
      if (form.getAttribute("data-validate") === "register" && password) {
        if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/.test(password.value)) {
          messages.push("Password needs 8+ characters with upper, lower, and a number.");
        }
        if (confirm && confirm.value !== password.value) {
          messages.push("The two passwords do not match.");
        }
      }
      if (messages.length) {
        event.preventDefault();
        alert(messages.join("\n"));
      } else {
        var loader = document.getElementById("compass-loader");
        if (loader) loader.hidden = false;
      }
    });
  });

  document.querySelectorAll('a.btn-primary, button.btn-primary').forEach(function (el) {
    el.addEventListener("click", function () {
      if (el.tagName === "A") {
        var loader = document.getElementById("compass-loader");
        if (loader) loader.hidden = false;
      }
    });
  });

  window.addEventListener("pageshow", function () {
    var loader = document.getElementById("compass-loader");
    if (loader) loader.hidden = true;
  });

  window.addEventListener("message", function (event) {
    var data = event.data;
    if (!data || data.channel !== "grok-preview-bridge") return;
    if (data.type === "navigate" && typeof data.path === "string" && data.path.charAt(0) === "/" && data.path.charAt(1) !== "/") {
      window.location.href = data.path;
    }
    if (data.type === "history") {
      window.history.go(data.delta);
    }
  });
})();
