(function () {
  "use strict";

  var form = document.getElementById("answer-form");
  if (!form) return;

  var endpoint = form.getAttribute("data-autosave");
  var questionId = form.getAttribute("data-question");
  var tokenInput = form.querySelector('input[name="csrf_token"]');

  function selected() {
    return form.querySelector('input[name="option_id"]:checked');
  }

  function markSelected() {
    form.querySelectorAll(".option-card").forEach(function (card) {
      var on = card.querySelector("input") && card.querySelector("input").checked;
      card.classList.toggle("is-selected", !!on);
    });
  }

  function autosave() {
    var choice = selected();
    if (!choice || !endpoint) return;
    var body = new URLSearchParams();
    body.set("csrf_token", tokenInput ? tokenInput.value : "");
    body.set("option_id", choice.value);
    body.set("question_id", questionId);
    fetch(endpoint, {
      method: "POST",
      headers: {
        "X-Requested-With": "XMLHttpRequest",
        "X-CSRF-Token": tokenInput ? tokenInput.value : ""
      },
      body: body
    }).catch(function () { /* keep the full form submit as backup */ });
  }

  form.querySelectorAll('input[name="option_id"]').forEach(function (input) {
    input.addEventListener("change", function () {
      markSelected();
      autosave();
    });
  });

  form.addEventListener("keydown", function (event) {
    var cards = Array.prototype.slice.call(form.querySelectorAll('input[name="option_id"]'));
    var index = cards.findIndex(function (el) { return el.checked; });
    if (event.key === "ArrowRight" || event.key === "ArrowDown") {
      event.preventDefault();
      var next = cards[Math.min(cards.length - 1, index + 1)] || cards[0];
      next.checked = true;
      next.focus();
      markSelected();
      autosave();
    }
    if (event.key === "ArrowLeft" || event.key === "ArrowUp") {
      event.preventDefault();
      var prev = cards[Math.max(0, index - 1)] || cards[0];
      prev.checked = true;
      prev.focus();
      markSelected();
      autosave();
    }
  });

  markSelected();
})();
