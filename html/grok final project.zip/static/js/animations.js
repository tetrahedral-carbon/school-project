(function () {
  "use strict";
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduce) return;
  var card = document.querySelector(".question-card");
  if (!card) return;
  card.addEventListener("animationend", function () {
    card.removeAttribute("data-motion");
  });
})();
